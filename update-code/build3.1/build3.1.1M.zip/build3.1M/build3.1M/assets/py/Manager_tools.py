from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"C:\Users\rober\Desktop\QTDESIGNER\build3.1M\build3.1M\assets\ui\Manager_tools.ui"

class Ui_manager_tools(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_manager_tools, self).__init__()
        uic.loadUi(UI, self)

        self.pushButton_5.clicked.connect(self.closeWindow)
        #self.pushButton.clicked.connect(self.open_SetDiscount)
        #self.pushButton_2.clicked.connect(self.open_HistoryPurchase)
        #self.pushButton_3.clicked.connect(self.open_Void)
        #self.pushButton_4.clicked.connect(self.open_Masterlist)
        #self.pushButton_6.clicked.connect(self.open_PosReport)
        #self.pushButton_4.clicked.connect(self.loading)

    def closeWindow(self):
        self.close() 

    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)
        
        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept() 
        else:
            event.ignore()  


    def open_SetDiscount(self):
        self.SetDiscount = QtWidgets.QWidget()
        self.ui = Ui_SetDiscount()
        self.ui.setupUi(self.SetDiscount)
        self.SetDiscount.show()

    def open_Masterlist(self):
        self.Masterlist = QtWidgets.QWidget()
        self.ui = Ui_Masterlist()
        self.ui.setupUi(self.Masterlist)
        self.Masterlist.show()
    def open_Void(self):
        self.Void = QtWidgets.QWidget()
        self.ui = Ui_Void()
        self.ui.setupUi(self.Void)
        self.Void.show()

    def open_HistoryPurchase(self):
        self.HistoryPurchase = QtWidgets.QMainWindow()
        self.ui = Ui_HistoryPurchase()
        self.ui.setupUi(self.HistoryPurchase)
        self.HistoryPurchase.show()

    def open_PosReport(self):
        self.POS_Report = QtWidgets.QWidget()
        self.ui = Ui_POS_Report()
        self.ui.setupUi(self.POS_Report)
        self.POS_Report.show()


        
        


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_manager_tools()
    window1.show()
    sys.exit(app.exec_())