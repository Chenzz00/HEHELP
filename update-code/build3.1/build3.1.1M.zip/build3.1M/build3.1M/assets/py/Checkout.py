from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"C:\Users\rober\Desktop\QTDESIGNER\build3.1M\build3.1M\assets\ui\Checkout.ui"

class Ui_checkout(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_checkout, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        self.pushButton.clicked.connect(self.closeWindow)

    def closeWindow(self):
        self.close()

    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)
        
        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept() 
        else:
            event.ignore()  

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_checkout()
    window1.show()
    sys.exit(app.exec_())
