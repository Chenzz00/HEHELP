from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"C:\Users\rober\Desktop\QTDESIGNER\build3.1M\build3.1M\assets\ui\close.ui"

class Ui_close(QtWidgets.QDialog):
    closeConfirmed = pyqtSignal()
    def __init__(self):
        super(Ui_close, self).__init__()
        uic.loadUi(UI, self)

        self.pushButton.clicked.connect(self.on_accept)
        self.pushButton_2.clicked.connect(self.reject)

    def on_accept(self):
        # Emit the custom signal
        self.closeConfirmed.emit()
        self.accept()

    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_close()
    window1.exec_()
    sys.exit(app.exec_())
