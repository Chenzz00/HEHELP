import mysql.connector
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from close import Ui_close
import sys

UI = r"assets\ui\Modify_Account.ui"

class Ui_Register(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_Register, self).__init__()
        uic.loadUi(UI, self)
        self.pushButton.clicked.connect(self.closeWindow)
        self.lineEdit.textChanged.connect(self.check_inputs)
        self.lineEdit_2.textChanged.connect(self.check_inputs)
        self.lineEdit_3.textChanged.connect(self.check_inputs)
        self.pushButton_2.clicked.connect(self.adduser)
        self.connect_db()
        self.pushButton_2.setEnabled(False) 

    def closeWindow(self):
        self.close()

    def check_inputs(self):
        if self.lineEdit.text() and self.lineEdit_2.text() and self.lineEdit_3.text():
            self.pushButton_2.setEnabled(True)
        else:
            self.pushButton_2.setEnabled(False)

    def connect_db(self):
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="atillopobletedeleon@674647",
                database="generaldatabase"
            )
            self.mycursor = self.mydb.cursor()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def adduser(self):
        try:
            self.comboBox_2.setEnabled(True)
            username = self.lineEdit.text()
            password = self.lineEdit_2.text()
            status = self.comboBox_2.currentText()
            sqluser = "INSERT INTO users(username, password, status) VALUES (%s, %s, %s)"
            newacc = (username, password, status)
            self.mycursor.execute(sqluser, newacc)
            self.mydb.commit()
            self.label_6.setText("Account successfully registered")
            self.label_6.setStyleSheet("color: green;")
            
            self.lineEdit.clear()
            self.lineEdit_2.clear()
            self.lineEdit_3.clear()
            
            QTimer.singleShot(3000, self.clear_message)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def clear_message(self):
        self.label_6.setText("")

    def modify_account(self):
        try:
            username = self.lineEdit.text()
            password = self.lineEdit_2.text()
            self.comboBox_2.setEnabled(False)
            status = self.comboBox_2.setCurrentIndex(2)
            sqluser = f'-- SET SQL_SAFE_UPDATES = 0; UPDATE users SET username = {username}, password = {password} WHERE status = "OWNER"; SELECT * FROM users;'
            newacc = (username, password, status)
            self.mycursor.execute(sqluser, newacc)
            self.mydb.commit()
            self.label_6.setText("Account successfully registered")
            self.label_6.setStyleSheet("color: green;")
            
            self.lineEdit.clear()
            self.lineEdit_2.clear()
            self.lineEdit_3.clear()
            
            QTimer.singleShot(3000, self.clear_message)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def new_account(self):
        pass
    
    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + f"{sqlstate}"
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    def closeEvent(self, event):
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)

        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_Register()
    window.show()

    sys.exit(app.exec_())