class tryy:
    def __init__(self, barcode, ItemName, brand, category, price):
        self.barcode = barcode
        self.Itemname = ItemName
        self.brand = brand
        self.category = category
        self.price = price

obj = tryy(barcode=0, ItemName=None, brand=None, category=None, price =0)



