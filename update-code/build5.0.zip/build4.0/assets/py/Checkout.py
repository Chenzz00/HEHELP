from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
from datetime import datetime
import random
import string
import sys
import os
import bggg
from DASHBOARD import Ui_dashboard

UI = r"assets\ui\Checkout.ui"

class Ui_checkout(QtWidgets.QMainWindow):
    refresh_dashboard = pyqtSignal()
    def __init__(self, dashboard):
        super(Ui_checkout, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Payment_Amount.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backtoDashboard)
        self.CTransaction.setEnabled(False)
        self.Payment_Amount.textChanged.connect(self.validate_payment_amount)
        self.Checkout_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Assign the dashboard object to an attribute
        self.dashboard = dashboard

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

        # Connect signals
        self.Payment_Amount.textChanged.connect(self.populate_checkoutTable)
        self.transaction_saved = False  # Add this line

        # Populate the checkout table initially
        self.populate_checkoutTable()

    def populate_checkoutTable(self):
        try:
            # Calculate subtotal
            query = """
                SELECT SUM(i.product_quantity * m.price) AS total_price
                FROM Item_List i
                INNER JOIN masterlist m ON i.Barcode_Number = m.barcode_number
            """
            self.mycursor.execute(query)
            total_price = self.mycursor.fetchone()[0]

            # Ensure total_price is not negative
            total_price = max(total_price, 0)

            # Fetching individual items
            query_items = """
                SELECT m.product_name, i.product_quantity, m.price 
                FROM Item_List i
                INNER JOIN masterlist m ON i.Barcode_Number = m.barcode_number
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()

            self.Checkout_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    item = QTableWidgetItem(str(value))
                    self.Checkout_Table.setItem(row_number, column_number, item)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255)) 

            # Get the payment amount from Payment_Amount line edit
            payment_text = self.Payment_Amount.text()
            if payment_text:
                payment_amount = max(float(payment_text), 0)  # Ensure payment_amount is not negative
            else:
                payment_amount = 0

            # Calculate discount only if payment amount is greater than or equal to subtotal
            if payment_amount >= total_price:
                # Get the selected discount from the dashboard
                discount_index = self.dashboard.Set_Discount.currentIndex()
                discount_text = self.dashboard.Set_Discount.currentText()
                if discount_index == 0:
                    discount_percentage = 0  # No discount
                elif discount_index == 1:
                    discount_percentage = 0.10  # 10% discount
                elif discount_index == 2:
                    discount_percentage = 0.25  # 25% discount
                elif discount_index == 3:
                    discount_percentage = 0.50  # 50% discount
                elif discount_index == 4:
                    custom_discount, ok = QInputDialog.getDouble(self, "Custom Discount", "Enter custom discount percentage:")
                    if ok:
                        discount_percentage = custom_discount / 100
                    else:
                        discount_percentage = 0  # No discount if user cancels
                else:
                    discount_percentage = 0  # Default to no discount for invalid index

                # Calculate discount and discounted total
                discount = total_price * discount_percentage
                discounted_total = total_price - discount
                # Ensure discounted_total is not negative
                discounted_total = max(discounted_total, 0)

                # Prepare discount line for textEdit
                if discount_index == 0:
                    second_line = "<b>DISCOUNT:</b> No Discount"
                elif discount_index == 4:
                    second_line = f"<b>DISCOUNT:</b> Custom Discount ({discount_text})"
                else:
                    second_line = f"<b>DISCOUNT:</b> {discount_text}"

                # Calculate change
                change = payment_amount - discounted_total
                # Ensure change is not negative
                change = max(change, 0)

                # Update the Price_Label with the total price
                first_line = f"<b>Sub-total:</b> ₱{total_price:.2f}"
                third_line = f"<b>Total:</b> ₱{discounted_total:.2f}"
                fourth_line = "------------"
                fifth_line = f"<b>Change:</b> ₱{change:.2f}"
            else:
                # If payment amount is less than subtotal, set discount and change to 0
                discount_percentage = 0
                discount = 0
                discounted_total = total_price
                change = 0
                second_line = "<b>DISCOUNT:</b> No Discount"
                first_line = f"<b>Sub-total:</b> ₱{total_price:.2f}"
                third_line = f"<b>Total:</b> ₱{discounted_total:.2f}"
                fourth_line = "------------"
                fifth_line = "<b>Change:</b> ₱0.00"

            # Concatenate the lines into a single HTML string
            show_textEdit = f"{first_line}<br>{second_line}<br>{third_line}<br>{fourth_line}<br>{fifth_line}"
            self.textEdit.setHtml(show_textEdit)

            # Update the Change_Display line edit
            self.Change_Display.setText(f"₱{change:.2f}")

            # Make table read-only
            self.Checkout_Table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        except mysql.connector.Error as err:
            print(err)

        self.CTransaction.clicked.connect(self.save_transaction_to_history)
    
    

    def save_transaction_to_history(self):
        try:
            # Check if the transaction has already been saved
            if self.transaction_saved:
                return  # If transaction already saved, exit the function

            # Get the current date and time
            current_datetime = datetime.now()
            transaction_date = current_datetime.strftime("%Y-%m-%d")
            transaction_time = current_datetime.strftime("%H:%M:%S")

            # Get the payment amount from the Payment_Amount line edit
            payment_amount_text = self.Payment_Amount.text()
            if not payment_amount_text:
                QMessageBox.warning(self, "Empty Payment Amount", "Please enter a payment amount.")
                return  # If payment amount is empty, exit the function

            # Convert the payment amount text to float
            payment_amount = float(payment_amount_text)

            # Generate a random 5-digit transaction ID
            transaction_id = ''.join(random.choices(string.digits, k=5))

            # Fetch user_id of the logged-in user from the dashboard
            user_id_query = """
                SELECT user_id 
                FROM accountmanagement 
                WHERE activity = 'ONLINE'
            """
            self.mycursor.execute(user_id_query)
            user_id = self.mycursor.fetchone()[0]

            # Get the selected discount from the dashboard
            discount_percentage = self.dashboard.Set_Discount.currentText()

            # Fetch the discount ID from Discount_List table based on the selected discount percentage
            discount_id_query = """
                SELECT Discount_List.Discount_ID 
                FROM Discount_List 
                WHERE Discount_List.Discount_Type = 'percentage' 
                AND Discount_List.Discount = %s
            """
            self.mycursor.execute(discount_id_query, (discount_percentage,))
            discount_row = self.mycursor.fetchone()

            # Check if discount_row is None
            if discount_row is None:
                QMessageBox.warning(self, "Discount Not Found", f"No matching discount found for '{discount_percentage}'.")
                return

            discount_id = discount_row[0]

            # Extract subtotal and change from textEdit
            text = self.textEdit.toPlainText()
            lines = text.split('\n')
            subtotal_line = lines[0].split(': ')[1]  # Extract subtotal from the first line
            subtotal = float(subtotal_line.removeprefix("₱"))

            change_line = lines[-1].split(': ')[1]  # Extract change from the last line
            change = float(change_line.removeprefix("₱"))

            # Calculate Transaction_Total based on subtotal and discount
            if discount_percentage == "No Discount":
                discount_amount = 0
            else:
                discount_amount = subtotal * (float(discount_percentage.strip('%')) / 100)
            transaction_total = subtotal - discount_amount

            # Insert transaction data into HistoryOfPurchase table
            insert_query = """
                INSERT INTO HistoryOfPurchase (Transaction_ID, user_id, discount_id, Transaction_Sub_Total, 
                                            Transaction_Total_Change, Transaction_Total, Transaction_Date, 
                                            Transaction_Time)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            self.mycursor.execute(insert_query, (transaction_id, user_id, discount_id, subtotal, change, 
                                                transaction_total, transaction_date, transaction_time))
            self.mydb.commit()

            # Set the transaction_saved flag to True to indicate that the transaction has been saved
            self.transaction_saved = True

            # Show message informing the user that the transaction has been saved
            QMessageBox.information(self, "Transaction Saved", "Transaction details saved to HistoryOfPurchase table.")

            # Clear all data from the Item_List table
            clear_item_list_query = "DELETE FROM Item_List"
            self.mycursor.execute(clear_item_list_query)
            self.mydb.commit()
    
            # Go back to the dashboard
            self.openHOP()
            self.close()

        except mysql.connector.Error as err:
            print("MySQL Error:", err)

    def validate_payment_amount(self):
        # Get the payment amount text from Payment_Amount line edit
        payment_text = self.Payment_Amount.text()

        # Disable CTransaction button by default
        self.CTransaction.setEnabled(False)

        # Check if payment_text is not empty
        if payment_text:
            try:
                # Convert payment_text to float
                payment_amount = float(payment_text)
                
                # Get the subtotal from the first line of textEdit
                first_line_text = self.textEdit.toPlainText().split('\n')[0]
                subtotal = float(first_line_text.split(': ')[1].removeprefix("₱"))

                # Enable CTransaction button if payment amount is greater than or equal to subtotal
                if payment_amount >= subtotal:
                    self.CTransaction.setEnabled(True)
            except ValueError:
                # Handle invalid input (non-numeric input)
                pass
        




    def openHOP(self):
        from History_Purchase import Ui_History_Purchase
        self.HOP = Ui_History_Purchase()
        
        self.HOP.show()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backtoDashboard()
                
            else:
                event.ignore()
        else:
            event.accept()

    def backtoDashboard(self):
        self.dashboard.show()
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    dashboard = Ui_dashboard()
    window1 = Ui_checkout(dashboard)  # Pass the dashboard object to Ui_checkout
    window1.show()
    sys.exit(app.exec_())
