from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import bggg

UI = r"assets\ui\Void.ui"

class Ui_Void_List(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Void_List, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Invoice.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToMTools)
        self.Void_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # Establish a database connection
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

        # Fetch and display transaction details from the void_list table
        self.populate_dashboard_table()

        # Connect double-click event to deselect the row
        self.Void_Table.itemDoubleClicked.connect(self.deselectRow)
        
        # Connect textChanged signal to filter the table based on invoice number
        self.Search_Invoice.textChanged.connect(self.filterTableByInvoice)

        # Connect Filter_User combo box change event to filter the table by user
        self.Filter_User.currentIndexChanged.connect(self.filterUser)

    def filterTableByInvoice(self, text):
        # Convert text to lowercase for case-insensitive search
        text = text.lower()
        
        # Filter the table based on the input text (invoice number)
        for row in range(self.Void_Table.rowCount()):
            invoice_item = self.Void_Table.item(row, 0)  # Assuming invoice number is in the first column
            if invoice_item:
                invoice_number = invoice_item.text().lower()
                if text in invoice_number:
                    self.Void_Table.setRowHidden(row, False)
                else:
                    self.Void_Table.setRowHidden(row, True)
            else:
                self.Void_Table.setRowHidden(row, True)

    def backToMTools(self):
        from Manager_tools import Ui_manager_tools
        self.mTools = Ui_manager_tools()
        self.mTools.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToMTools()  
            else:
                event.ignore()
        else:
            event.accept()

    def update_table(self, data=None):
        try:
            if data is None:
                self.mycursor.execute("SELECT vl.void_id, am.first_name, am.first_name, vl.date_voided, vl.time_voided FROM Void_List vl INNER JOIN accountmanagement am ON vl.user_id = am.user_id")
                data = self.mycursor.fetchall()
            
            self.Void_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    self.Void_Table.setItem(row_number, column_number, QTableWidgetItem(str(value)))
        
        except mysql.connector.Error as err:
            print(err)

    def filterUser(self):
        selected_user = self.Filter_User.currentText()
        if selected_user == "All" or not selected_user:  # Show all data if "All" is selected or if selection goes back to default
            self.update_table()  # Update table with data for all users
        else:
            try:
                # Execute MySQL query to fetch data for the selected user
                query_data = """
                    SELECT vl.void_id, am.first_name, am.first_name, vl.date_voided, vl.time_voided
                    FROM Void_List vl
                    INNER JOIN accountmanagement am ON vl.user_id = am.user_id
                    WHERE am.first_name = %s
                """
                self.mycursor.execute(query_data, (selected_user,))
                data = self.mycursor.fetchall()

                # Update the table with the fetched data
                self.update_table(data)

            except mysql.connector.Error as err:
                print("Error:", err)


    def populate_dashboard_table(self):
        try:
            # Fetch unique first names from the accountmanagement table
            query = """
                SELECT DISTINCT am.first_name
                FROM accountmanagement am
            """
            self.mycursor.execute(query)
            first_names = self.mycursor.fetchall()

            # Populate unique first names into Filter_User widget
            self.Filter_User.clear()
            self.Filter_User.addItem("All")  # Add an option to show all data
            for first_name in first_names:
                self.Filter_User.addItem(first_name[0])  # Assuming Filter_User is the name of the widget

            # Fetch item_list_id (Invoice Number), cashier's name, voided by, date voided, and time voided
            # from the HistoryOfPurchase and accountmanagement tables
            query = """
                SELECT vl.void_id, am.first_name, am.first_name, vl.date_voided, vl.time_voided
                FROM Void_List vl
                INNER JOIN accountmanagement am ON vl.user_id = am.user_id
            """
            self.mycursor.execute(query)
            data = self.mycursor.fetchall()

            self.update_table(data)

        except mysql.connector.Error as err:
            print(err)

    def deselectRow(self, item):
        item.setSelected(False)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Void_List()
    window1.show()
    sys.exit(app.exec_())
