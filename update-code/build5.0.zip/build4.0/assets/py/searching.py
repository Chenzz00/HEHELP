from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import Database
from Quantity import Ui_Quantity
import mysql.connector
import sys
import bggg
UI = r"assets\ui\Searching.ui"

class Ui_searching(QtWidgets.QMainWindow):
    productSelected = pyqtSignal(str, float, int)
    
    def __init__(self,user_id=None):
        super(Ui_searching, self).__init__()
        uic.loadUi(UI, self)
        self.user_id = user_id 
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Barcode.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Cart_Button.clicked.connect(self.showQuantityDialog)
       
        self.Search_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.Search_Barcode.textChanged.connect(self.searchBarcode)
        
        self.mydb = mysql.connector.connect(
            host="localhost", 
            user="root", 
            passwd="CPET8L", 
            database="generaldatabase", 
            port=3306)
        self.mycursor = self.mydb.cursor()

        self.update_table()
        self.Search_Table.itemDoubleClicked.connect(self.clearSelection)  # Connect double-click event

    def update_table(self, data=None):
        try:
            if data is None:
                self.mycursor.execute("SELECT barcode_number, product_name, category, price  FROM masterlist")
                data = self.mycursor.fetchall()
            
            self.Search_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    self.Search_Table.setItem(row_number, column_number, QTableWidgetItem(str(value)))
        
        except mysql.connector.Error as err:
            print(err)

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def clearSelection(self):
        self.Search_Table.clearSelection()  # Clear table selection

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()

    def searchBarcode(self, barcode):
        try:
            query = "SELECT barcode_number, product_name, category, price FROM masterlist WHERE barcode_number LIKE %s"
            self.mycursor.execute(query, (f"{barcode}%",))  
            result = self.mycursor.fetchall()
            self.update_table(result)
        except mysql.connector.Error as err:
            print(err)

    def showQuantityDialog(self):
        selected_item = self.Search_Table.selectedItems()
        if selected_item:
           
            barcode = selected_item[0].text()
            self.quantity_dialog = Ui_Quantity()
            self.quantity_dialog.quantityAdded.connect(lambda quantity: self.addProductToCart(barcode, quantity))
            self.quantity_dialog.setWindowModality(Qt.WindowModal) 
            self.quantity_dialog.show()
        else:
            QMessageBox.warning(self, "Warning", "Please select an item.")

    def populate_dashboard_table(self):
        try:
            query_items = """
                SELECT m.product_name, i.product_quantity, m.price 
                FROM Item_List i
                INNER JOIN masterlist m ON i.Barcode_Number = m.barcode_number
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()
            
            self.Dashboard_Table.setRowCount(len(data))
            for row_number, (product_name, quantity, price) in enumerate(data):
                # Set the product name, quantity, and price in the table
                self.Dashboard_Table.setItem(row_number, 0, QTableWidgetItem(product_name))  # Product Name
                self.Dashboard_Table.setItem(row_number, 1, QTableWidgetItem(str(quantity)))   # Quantity
                self.Dashboard_Table.setItem(row_number, 2, QTableWidgetItem(f"₱{price:.2f}"))  # Price

                # Set background and foreground colors
                for column_number in range(3):  # Loop through columns
                    item = self.Dashboard_Table.item(row_number, column_number)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255))

        except mysql.connector.Error as err:
            print(err)








if __name__ == "__main__":
    app = QApplication(sys.argv)
    searching_window = Ui_searching()
    searching_window.show()
    sys.exit(app.exec_())