from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import os
import bggg
import random
import string

# Import UI files
UI_DASHBOARD = r"assets\ui\Dashboard.ui"

class Ui_dashboard(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_dashboard, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.Search_Button.clicked.connect(self.openSearch)
        self.CheckOut.clicked.connect(self.openCheckOut)
        self.Manager_Tools.clicked.connect(self.openManagerTools)
        self.AM_Button.clicked.connect(self.openAccountManagement)
        self.Void_Button.clicked.connect(self.void_selected_item)  
        self.Dashboard_Table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.Set_Discount.setEnabled(False)

        # Connect the opening of the Set_Discount combobox to the presence of data in the dashboard table
        self.Dashboard_Table.itemChanged.connect(self.enable_discount_combobox)
        
        self.update_time()

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        
        self.mycursor = self.mydb.cursor()

        self.populate_dashboard_table()
        self.set_user()

    
        self.Set_Discount.currentIndexChanged.connect(self.calculate_total)  

  

    def calculate_total(self, index):
        subtotal = float(self.Price_Label.text().removeprefix("₱"))
        first_line = "<b>SUB-TOTAL:</b> ₱{:.2f}".format(subtotal)
        second_line = f"<b>DISCOUNT:</b>" +  self.Set_Discount.currentText()
        show_textEdit = f"{first_line}<br>{second_line}"
        self.textEdit.setHtml(show_textEdit)

    def openSearch(self):
        from searching import Ui_searching
        self.window = Ui_searching()
        self.window.setWindowModality(Qt.ApplicationModal)
        self.window.show()
        self.hide()

    def openCheckOut(self):
        if self.Dashboard_Table.rowCount() == 0:
            QMessageBox.warning(self, "Empty Dashboard", "Please input items before proceeding to checkout.")
            return
        from Checkout import Ui_checkout
        self.checkout = Ui_checkout(self)
        self.checkout.setWindowModality(Qt.ApplicationModal)
        self.checkout.refresh_dashboard.connect(self.refresh_dashboard_table)
        self.checkout.show()
        self.close()
                
       
    def refresh_dashboard_table(self):
        try:
            self.populate_dashboard_table() 
            QMessageBox.information(self, "Dashboard Refreshed", "Dashboard table has been refreshed.")
        except Exception as e:
            print("Error refreshing dashboard table:", e)

    def fetch_quantity(self, quantity, user_role):
        self.quantity_label.setText(f"Quantity: {quantity}")

    def openManagerTools(self):
        from Manager_tools import Ui_manager_tools
        self.managertools = Ui_manager_tools()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.hide()

    def openAccountManagement(self):
        from account_management import Ui_accountManagement
        self.accountManagement = Ui_accountManagement()
        self.accountManagement.setWindowModality(Qt.ApplicationModal)
        self.accountManagement.show()
        self.hide()

    def update_time(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        time_text = current_time.toString("hh:mm:ss AP")
        date_text = current_date.toString("MM/dd/yy")
        self.DateTime_Label.setText(f"{time_text}  {date_text}")
        font = self.DateTime_Label.font()
        font.setPointSize(19)
        self.DateTime_Label.setFont(font)

    def backToLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from logout import Ui_logout
            self.close_dialog = Ui_logout()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            result = self.close_dialog.exec_()
            if result == QDialog.Accepted:
                self.backToLogin()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def set_user(self):
        try:
            syntax = 'SELECT first_name, status FROM accountmanagement WHERE activity = "ONLINE"'
            self.mycursor.execute(syntax)
            namestat = self.mycursor.fetchone()
            self.User_Label.setText(f"WELCOME {namestat[0].upper()}! USER ROLE: {namestat[1]}")
        except mysql.connector.Error as err:
            print(err)
    
    def populate_dashboard_table(self):
        try:
            # Fetch the total price of all items in the dashboard
            query_total_price = """
                SELECT SUM(product_quantity * price) AS total_price
                FROM Item_List
            """
            self.mycursor.execute(query_total_price)
            total_price = self.mycursor.fetchone()[0] or 0
            self.Price_Label.setText(f"₱{total_price:.2f}")

            # Fetch the product_name, product_quantity, and price from the Item_List table
            query_items = """
                SELECT product_name, product_quantity, price
                FROM Item_List
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()

            self.Dashboard_Table.setRowCount(len(data))
            for row_number, (product_name, product_quantity, price) in enumerate(data):
                # Set the product_name, product_quantity, and price in the table
                self.Dashboard_Table.setItem(row_number, 0, QTableWidgetItem(product_name))  # Product Name
                self.Dashboard_Table.setItem(row_number, 1, QTableWidgetItem(str(product_quantity)))  # Quantity
                self.Dashboard_Table.setItem(row_number, 2, QTableWidgetItem(f"₱{price:.2f}"))  # Price

                # Set background and foreground colors
                for column_number in range(3):  # Loop through columns
                    item = self.Dashboard_Table.item(row_number, column_number)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255))

        except mysql.connector.Error as err:
            print(err)

    def enable_discount_combobox(self):
        if self.Dashboard_Table.rowCount() > 0:
            self.Set_Discount.setEnabled(True)
        else:
            self.Set_Discount.setEnabled(False)

    def void_selected_item(self):
        selected_row = self.Dashboard_Table.currentRow()
        if selected_row >= 0:
            confirmation = QMessageBox.question(self, "Confirmation", "Are you sure you want to void this item?",
                                                QMessageBox.Yes | QMessageBox.No)
            if confirmation == QMessageBox.Yes:
                item = self.Dashboard_Table.item(selected_row, 0)
                if item is not None:
                    product_name = item.text()
                    try:
                        query = f"""
                            DELETE i FROM Item_List i
                            INNER JOIN masterlist m ON i.Barcode_Number = m.Barcode_Number
                            WHERE m.product_name = '{product_name}'
                        """
                        self.mycursor.execute(query)
                        self.mydb.commit()
                        self.Dashboard_Table.removeRow(selected_row)
                        self.update_total_price()
                    except mysql.connector.Error as err:
                        print("Error:", err)
        else:
            QMessageBox.warning(self, "No item selected", "Please select an item to void.")
        
    
    
    def update_total_price(self):
        total_price = 0.0
        for row in range(self.Dashboard_Table.rowCount()):
            quantity_item = self.Dashboard_Table.item(row, 1)
            price_item = self.Dashboard_Table.item(row, 2)
            if quantity_item and price_item:
                quantity = float(quantity_item.text())
                price = float(price_item.text())
                total_price += quantity * price
        self.Price_Label.setText(f"₱{total_price:.2f}")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    dashboard_ui = Ui_dashboard()
    dashboard_ui.show()

    sys.exit(app.exec_())
