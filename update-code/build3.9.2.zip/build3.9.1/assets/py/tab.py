from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"assets\ui\TAB.ui"

class Ui_tab(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_tab, self).__init__()
        uic.loadUi(UI, self)

    # Hide the header and tab widget lines
        self.tabWidget.tabBar().hide()
        self.tabWidget.setStyleSheet("QTabWidget::pane { border: none; }")
        

        self.pushButton = self.findChild(QPushButton, 'pushButton')
        self.pushButton_2 = self.findChild(QPushButton, 'pushButton_2')
        self.tabWidget = self.findChild(QTabWidget, 'tabWidget')
        
        # Connect the buttons' clicked signals to the respective methods
        self.pushButton.clicked.connect(self.switchToTab2)
        self.pushButton_2.clicked.connect(self.switchToTab1)
        self.tabWidget.setCurrentIndex(0)
    
    def switchToTab2(self):
        # Assuming tab 2 has an index of 1
        self.tabWidget.setCurrentIndex(1)
    
    def switchToTab1(self):
        # Assuming tab 1 has an index of 0
        self.tabWidget.setCurrentIndex(0)
    
    def closeWindow(self):
        self.close()
    
    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)
        
        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept() 
        else:
            event.ignore()  

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_tab()
    window1.show()
    sys.exit(app.exec_())
