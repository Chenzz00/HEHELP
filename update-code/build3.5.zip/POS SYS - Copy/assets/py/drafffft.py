from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer, QTime
import sys

class Ui_clocktime(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_clocktime, self).__init__()
        uic.loadUi("clocktime.ui", self)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  

    def update_time(self):
        current_time = QTime.currentTime()
        time_text = current_time.toString("hh:mm:ss AP")
        self.label.setText(time_text)
        font = self.label.font()
        font.setPointSize(20)  
        self.label.setFont(font)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_clocktime()
    window1.show()
    sys.exit(app.exec_())
