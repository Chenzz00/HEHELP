from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys

# Import UI files
UI_LOGIN = r"assets\ui\LOGINUI.ui"
mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="atillopobletedeleon@674647",
                database="generaldatabase",
                port = 3306
            )

class Ui_login(QtWidgets.QMainWindow):
    loginSuccessful = QtCore.pyqtSignal(str, str, str) 

    def __init__(self):
        super(Ui_login, self).__init__()
        uic.loadUi(UI_LOGIN, self)

        self.lineEdit.setValidator(None)
        self.lineEdit_2.setValidator(None)
        self.pushButton_2.clicked.connect(self.reset_owner)
        self.pushButton.clicked.connect(self.validateLogin)

    def validateLogin(self):
        
        username = self.lineEdit.text()
        password = self.lineEdit_2.text()
        selected_status = self.comboBox.currentText() #input ng user sa combobox

        try:
            global mydb, is_new_account
            mycursor = mydb.cursor()

            sql_query = "SELECT * FROM users WHERE username = %s AND password = %s"
            mycursor.execute(sql_query, (username, password))
            result = mycursor.fetchone() #list ng nahanap ng db
            #if new account (admin user pass + owner status), modify the admin admin acc before login
            
            if result: #kapag may nahanap
                db_status = result[2]
                if result[0] == "admin" and result[1] == "admin" and selected_status == "OWNER":
                    global is_new_account
                    is_new_account = True
                    self.open_ModifyAccount()
        
                elif db_status == selected_status: 
                    self.loginSuccessful.emit(username, password, db_status)  
                    self.openDashboard()  
                    self.close()  
                    
                else:
                    
                    self.showMessageBox("Incorrect user status", "Login Failed")
            else:
                self.showMessageBox("Invalid username or password", "Login Failed")

        except mysql.connector.Error as err:
            print("Error:", err)

    def reset_owner(self):
        global mydb
        try:
            syntax = '-- SET SQL_SAFE_UPDATES = 0; UPDATE users SET username = "admin", password = "admin" WHERE status = "OWNER"; SELECT * FROM users;'
            self.resetOwner = mydb.cursor()
            self.resetOwner.execute(syntax)
            print("Succesfully reset")

        except mysql.connector.Error as err:
            self.showMessageBox((err.errno, err.sqlstate, err.msg), "ERROR")

    def openDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.ui = Ui_dashboard()
        self.ui.setWindowModality(Qt.ApplicationModal)
        self.ui.show()


    def open_ModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        if is_new_account == True:
            self.window.new_account() 
        self.window.show()

            


    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: white; color: black;")
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_login()
    window1.show()
    sys.exit(app.exec_())
