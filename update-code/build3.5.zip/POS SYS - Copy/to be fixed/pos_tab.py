from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
from account_management import Ui_accountManagement
import os
from DASHBOARD import Ui_dashboard

UI = r"assets\ui\pos_tab.ui"
ACCOUNT_MANAGEMENT_UI = r"assets\ui\Account_Management.ui"

class Ui_POS(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_POS, self).__init__()
        uic.loadUi(UI, self)

        self.tabWidget.tabBar().hide()
        self.tabWidget.setStyleSheet("QTabWidget::pane { border: none; }")
        self.tabWidget.setCurrentIndex(0)

        self.pushButton = self.findChild(QPushButton, 'pushButton')
        self.pushButton_4 = self.findChild(QPushButton, 'pushButton_4')
        self.pushButton_2 = self.findChild(QPushButton, 'pushButton_2')
        self.lineEdit_5 = self.findChild(QLineEdit, 'lineEdit_5')
        self.lineEdit_3 = self.findChild(QLineEdit, 'lineEdit_3')
        self.lineEdit = self.findChild(QLineEdit, 'lineEdit')
        self.lineEdit_2 = self.findChild(QLineEdit, 'lineEdit_2')

        self.lineEdit_5.textChanged.connect(self.check_inputs)
        self.lineEdit_3.textChanged.connect(self.check_inputs)

        self.pushButton_4.clicked.connect(self.switchToTab1)
        self.pushButton_2.clicked.connect(self.adduser)

        self.pushButton.clicked.connect(self.validateLogin)

        self.account_management = Ui_accountManagement()

        self.account_management.load_data()  
        

        self.connect_db()
        self.default_admin_used = False
        self.updated_admin_credentials = None

    def switchToTab1(self):
        self.tabWidget.setCurrentIndex(0)

    def check_inputs(self):
        if self.lineEdit_5.text() and self.lineEdit_3.text():
            self.pushButton_2.setEnabled(True)
        else:
            self.pushButton_2.setEnabled(False)

    def validateLogin(self):
        username = self.lineEdit.text()
        password = self.lineEdit_2.text()

        
        if username == "admin" and password == "admin" and not self.default_admin_used:
            self.saveAdminCredentials("new_admin", "new_password") 
            self.default_admin_used = True
            self.loadAdminCredentials()
            self.tabWidget.setCurrentIndex(1)
            return

        if self.updated_admin_credentials and username == self.updated_admin_credentials[0] and password == self.updated_admin_credentials[1]:
            self.tabWidget.setCurrentIndex(1)
            return

        try:
            
            sql_query = "SELECT * FROM users WHERE username = %s AND password = %s AND status = 'OWNER'"
            self.mycursor.execute(sql_query, (username, password))
            result = self.mycursor.fetchone()

            if result:
                
                self.openDashboard()
            else:
                
                for row in range(self.account_management.tableWidget.rowCount()):
                    if (self.account_management.tableWidget.item(row, 0).text() == username and
                            self.account_management.tableWidget.item(row, 1).text() == password):
                        self.openDashboard()
                        return

            self.showMessageBox("Invalid username or password", "Login Failed")

        except mysql.connector.Error as err:
            self.showMessageBox(f"Database Error: {err}", "Login Failed")


    def loadAdminCredentials(self):
        if os.path.isfile("admin_credentials.txt"):
            with open("admin_credentials.txt", "r") as file:
                credentials = file.read().splitlines()
                if credentials and len(credentials) == 2:
                    self.lineEdit_5.setText(credentials[0])
                    self.lineEdit_3.setText(credentials[1])
                    self.default_admin_used = True

    def showMessageBox(self, message, title):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(message)
        msg.setWindowTitle(title)
        msg.exec_()

    def adduser(self):
        username = self.lineEdit_5.text()
        password = self.lineEdit_3.text()
        status = self.comboBox.currentText()  

        try:
            self.mycursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            existing_user = self.mycursor.fetchone()

            if existing_user:
                self.showMessageBox("Username already exists. Please choose a different username.", "Error")
            else:
                
                sql_insert = "INSERT INTO users (username, password, status) VALUES (%s, %s, %s)"
                self.mycursor.execute(sql_insert, (username, password, status))
                self.mydb.commit()

                
                self.account_management.load_data()

                self.showMessageBox("User added successfully.", "Success")

        except mysql.connector.Error as err:
            self.showMessageBox(f"Database Error: {err}", "Error")


    def saveAdminCredentials(self, username, password):
        status = "OWNER"
        with open("admin_credentials.txt", "w") as file:
            file.write(f"{username}\n{password}\n{status}")

    def openDashboard(self):
        self.dashboard_window = Ui_dashboard()
        self.dashboard_window.show()

    def connect_db(self):
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="atillopobletedeleon@674647",
                database="generaldatabase"
            )
            self.mycursor = self.mydb.cursor()
        except mysql.connector.Error as err:
            self.showMessageBox(f"Database Error: {err}", "Error")

    

    

    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + sqlstate
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)
        
        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window1 = Ui_POS()
    window1.show()
    sys.exit(app.exec_())
