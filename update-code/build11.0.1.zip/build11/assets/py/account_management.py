from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

import mysql.connector
import sys, os
import bggg

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/Account_Management.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)

class Ui_accountManagement(QtWidgets.QMainWindow):
    userSelected = QtCore.pyqtSignal(str, str, str)

    def __init__(self):
        super(Ui_accountManagement, self).__init__()
        uic.loadUi(UI, self)

        self.load_data()

        self.Account_Table.cellClicked.connect(self.handleCellClicked)
        self.Create_Button.clicked.connect(self.openModifyAccount)
        self.Refresh_Button.clicked.connect(self.load_data)
        self.Delete_Button.clicked.connect(self.delete_account)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        self.Change_Button.clicked.connect(self.openPermission)

        self.setStyleSheet("QMainWindow { border-image: url(:/nice/bg.png);; }")
        self.check_permissions()

    def check_permissions(self):
        # Fetch the current user's permissions and status.
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            port=3306,
            database="generaldatabase"
        )
        self.mycursor = self.mydb.cursor()
        self.mycursor.execute("SELECT user_id, status FROM accountmanagement WHERE activity = 'ONLINE'")
        result = self.mycursor.fetchone()
        if result:
            user_id, status = result
            self.mycursor.execute("SELECT * FROM permissions WHERE user_id = %s", (user_id,))
            result_permission = self.mycursor.fetchone()
            if result_permission:
                self.Create_Button.setEnabled(True)
                self.Delete_Button.setEnabled(True)
                self.Change_Button.setEnabled(True)
                if result_permission[8] == 0:
                    self.Create_Button.setEnabled(False)
                if result_permission[9] == 0:
                    self.Delete_Button.setEnabled(False)
                if status != "OWNER":
                    self.Change_Button.setEnabled(False)

    def openPermission(self):
        selected_row = self.Account_Table.currentRow()
        
        if selected_row >= 0:
            from Permissions import Ui_Permissions
            self.window = Ui_Permissions()
            self.window.setWindowModality(Qt.ApplicationModal)
            fname = self.Account_Table.item(selected_row, 0).text()
            lname = self.Account_Table.item(selected_row, 1).text()
            status = self.Account_Table.item(selected_row, 2).text()

            # Pass the current user's status to the Permissions window
            current_user_status = self.get_current_user_status()
            self.window.get_user_details(fname, lname, status, current_user_status)
            self.window.show()
        else:
            QtWidgets.QMessageBox.information(self, 'Change Permission', 'Please select a row first.')

    def get_current_user_status(self):
        # Fetch the current user's status
        self.mycursor.execute("SELECT status FROM accountmanagement WHERE activity = 'ONLINE'")
        result = self.mycursor.fetchone()
        if result:
            return result[0]
        return None

    def delete_account(self):
        selected_row = self.Account_Table.currentRow()
        if selected_row >= 0:
            first_name = self.Account_Table.item(selected_row, 0).text()
            last_name = self.Account_Table.item(selected_row, 1).text()

            try:
                self.mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    passwd="CPET8L",
                    port=3306,
                    database="generaldatabase"
                )
                self.mycursor = self.mydb.cursor()

                self.mycursor.execute("SELECT status FROM accountmanagement WHERE first_name = %s AND last_name = %s", (first_name, last_name))
                result = self.mycursor.fetchone()

                if result:
                    status = result[0]

                    if status.lower() == "owner":
                        QtWidgets.QMessageBox.critical(self, 'Delete Account Error', 'Cannot delete owner account.')
                        return

                    confirm_dialog = QtWidgets.QMessageBox.question(self, 'Delete Account', 
                                                                    'Are you sure you want to delete this account?', 
                                                                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
                    if confirm_dialog == QtWidgets.QMessageBox.Yes:
                        try:
                            sql = "DELETE FROM accountmanagement WHERE first_name = %s AND last_name = %s"
                            val = (first_name, last_name)
                            self.mycursor.execute(sql, val)
                            self.mydb.commit()

                            self.Account_Table.removeRow(selected_row)
                            self.Account_Table.clearSelection()

                            QtWidgets.QMessageBox.information(self, 'Delete Account', 'Account deleted successfully.')
                        except mysql.connector.Error as delete_err:
                            if delete_err.errno == 1451:
                                QtWidgets.QMessageBox.critical(self, 'Delete Account Error', 'Cannot delete owner account.')
                            else:
                                self.errorDisplay(delete_err.errno, delete_err.sqlstate, delete_err.msg)

            except mysql.connector.Error as err:
                self.errorDisplay(err.errno, err.sqlstate, err.msg)
        else:
            QtWidgets.QMessageBox.information(self, 'Delete Account', 'Please select a row to delete.')


    def openModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        self.window.setup(1)  
        self.window.setWindowModality(Qt.ApplicationModal) 
        self.window.show()

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.window = Ui_dashboard()
        self.window.show()
        self.hide()

    def handleCellClicked(self, row, column):
        username = self.Account_Table.item(row, 0).text()
        password = self.Account_Table.item(row, 1).text()
        status = self.Account_Table.item(row, 2).text()
        self.userSelected.emit(username, password, status)

    def load_data(self):
        self.Account_Table.setRowCount(0)
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="CPET8L",
                port=3306,
                database="generaldatabase"
            )
            self.mycursor = self.mydb.cursor()

            self.mycursor.execute("SELECT first_name, last_name, status FROM accountmanagement")
            result = self.mycursor.fetchall()
            self.Account_Table.setRowCount(len(result))
            self.Account_Table.setColumnCount(3)
            self.Account_Table.setHorizontalHeaderLabels(['First Name','Last Name', 'Status'])
            print(result)
            for row_number, row_data in enumerate(result):
                for column_number, data in enumerate(row_data):
                    item = QTableWidgetItem(str(data))
                    self.Account_Table.setItem(row_number, column_number, item)
            self.update()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + sqlstate
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backtoDashboard()
                
            else:
                event.ignore()
        else:
            event.accept()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window1 = Ui_accountManagement()
    window1.show()
    sys.exit(app.exec_())
