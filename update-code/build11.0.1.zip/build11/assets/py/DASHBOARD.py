from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import sys
import os
import bggg
import random
import string
import subprocess

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI_DASHBOARD = resource_path('assets/ui/Dashboard.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)
# Import UI files


class Ui_dashboard(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_dashboard, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.Search_Button.clicked.connect(self.openSearch)
        self.CheckOut.clicked.connect(self.openCheckOut)
        self.Manager_Tools.clicked.connect(self.openManagerTools)
        self.AM_Button.clicked.connect(self.openAccountManagement)
        self.Void_Button.clicked.connect(self.void_selected_item)

        self.Dashboard_Table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.Set_Discount.setEnabled(False)
        self.Dashboard_Table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        
        # Connect the opening of the Set_Discount combobox to the presence of data in the dashboard table
        self.Dashboard_Table.itemChanged.connect(self.enable_discount_combobox)
        
        self.update_time()

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        
        self.mycursor = self.mydb.cursor()

        self.populate_dashboard_table()
        self.set_user()
        self.calculate_total()
    
        self.Set_Discount.currentIndexChanged.connect(self.calculate_total)  


    
    def calculate_total(self):
        try:
            subtotal = float(self.Price_Label.text().removeprefix("₱"))
        except:
            subtotal = 0.0
        first_line = "<b>SUB-TOTAL:</b> ₱{:.2f}".format(subtotal)
        second_line = f"<b>DISCOUNT:</b>" +  self.Set_Discount.currentText()
        show_textEdit = f"{first_line}<br>{second_line}"
        self.textEdit.setHtml(show_textEdit)

    def openSearch(self):
        from searching import Ui_searching
        self.window = Ui_searching()
        self.window.setWindowModality(Qt.ApplicationModal)
        self.window.show()
        self.hide()

    def openCheckOut(self):
        if self.Dashboard_Table.rowCount() == 0:
            self.showMessageBox1("Please input items before proceeding to checkout", "Empty Dashboard")
            return
        from Checkout import Ui_checkout
        self.checkout = Ui_checkout(self)
        self.checkout.setWindowModality(Qt.ApplicationModal)
        self.checkout.refresh_dashboard.connect(self.refresh_dashboard_table)
        self.checkout.show()
        self.close()
                
       
    def refresh_dashboard_table(self):
        try:
            self.populate_dashboard_table() 
            QMessageBox.information(self, "Dashboard Refreshed", "Dashboard table has been refreshed.")
        except Exception as e:
            print("Error refreshing dashboard table:", e)

    def fetch_quantity(self, quantity, user_role):
        self.quantity_label.setText(f"Quantity: {quantity}")

    def openManagerTools(self):
        from Manager_tools import Ui_manager_tools
        self.managertools = Ui_manager_tools()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.close()

    def openAccountManagement(self):
        from account_management import Ui_accountManagement
        self.accountManagement = Ui_accountManagement()
        self.accountManagement.setWindowModality(Qt.ApplicationModal)
        self.accountManagement.show()
        self.close()

    def update_time(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        time_text = current_time.toString("hh:mm:ss AP")
        date_text = current_date.toString("MM/dd/yy")
        self.DateTime_Label.setText(f"{time_text}  {date_text}")
        font = self.DateTime_Label.font()
        font.setPointSize(19)
        self.DateTime_Label.setFont(font)

    def backToLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()

    def closeEvent(self, event):
        
        if event.spontaneous():
            from logout import Ui_logout
            
            self.close_dialog = Ui_logout()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            result = self.close_dialog.exec_()
            if result == QDialog.Accepted:
                self.backToLogin()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def set_user(self):
        try:
            syntax = 'SELECT first_name, status FROM accountmanagement WHERE activity = "ONLINE"'
            self.mycursor.execute(syntax)
            namestat = self.mycursor.fetchone()
            self.User_Label.setText(f"WELCOME {namestat[0].upper()}! USER ROLE: {namestat[1]}")

            # Automatically check permissions when setting the user
            self.check_permissions()
        except mysql.connector.Error as err:
            print(err)
    def populate_dashboard_table(self):
        try:
            # Fetch the total price of all items in the dashboard
            query_total_price = """
                SELECT SUM(il.product_quantity * m.price) AS total_price
                FROM Item_List il
                INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
                WHERE il.product_status = 'Standby'  # Only include items with Standby product status
            """
            self.mycursor.execute(query_total_price)
            total_price = self.mycursor.fetchone()[0] or 0
            self.Price_Label.setText(f"₱{total_price:.2f}")

            # Fetch the product_name, product_quantity, and price from the Item_List and masterlist tables
            query_items = """
                SELECT m.product_name, il.product_quantity, m.price
                FROM Item_List il
                INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
                WHERE il.product_status = 'Standby'  # Only include items with Standby product status
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()

            self.Dashboard_Table.setRowCount(len(data))
            for row_number, (product_name, product_quantity, price) in enumerate(data):
                # Set the product_name, product_quantity, and price in the table
                self.Dashboard_Table.setItem(row_number, 0, QTableWidgetItem(product_name))  # Product Name
                self.Dashboard_Table.setItem(row_number, 1, QTableWidgetItem(str(product_quantity)))  # Quantity
                self.Dashboard_Table.setItem(row_number, 2, QTableWidgetItem(f"₱{price:.2f}"))  # Price

                # Set background and foreground colors
                for column_number in range(3):  # Loop through columns
                    item = self.Dashboard_Table.item(row_number, column_number)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255))

            # Enable/disable the discount combo box based on whether there are items in the dashboard table
            self.enable_discount_combobox()

        except mysql.connector.Error as err:
            print(err)



    def enable_discount_combobox(self):
        if self.Dashboard_Table.rowCount() > 0:
            self.Set_Discount.setEnabled(True)
        else:
            self.Set_Discount.setEnabled(False)

    def void_selected_item(self):
        def generate_void_id():
            """Generate a unique 6-digit numeric ID."""
            return ''.join(random.choices(string.digits, k=6))

        selected_indexes = self.Dashboard_Table.selectedIndexes()
        if selected_indexes:
            confirmation = self.showMessageBox("Are you sure you want to void these items", "Confirmation")
            if confirmation == QMessageBox.Yes:
                selected_rows = set(index.row() for index in selected_indexes)
                for selected_row in selected_rows:
                    item = self.Dashboard_Table.item(selected_row, 0)
                    if item is not None:
                        product_name = item.text()
                        try:
                            # Fetch the item_list_id of the selected item
                            self.mycursor.execute(f"""
                                SELECT il.item_list_id, il.Barcode_Number, il.product_status
                                FROM Item_List il
                                INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
                                WHERE m.product_name = '{product_name}'
                            """)
                            result = self.mycursor.fetchone()
                            if result:
                                item_list_id, barcode_number, status = result[0], result[1], result[2]

                                # Fetch the user_id, first_name, and status of the currently logged-in user
                                self.mycursor.execute('SELECT user_id, first_name, status FROM accountmanagement WHERE activity = "ONLINE"')
                                user_info = self.mycursor.fetchone()
                                user_id, first_name, status = user_info[0], user_info[1], user_info[2]

                                # Generate a unique 6-digit Void_ID
                                void_id = generate_void_id()
                                while True:
                                    self.mycursor.execute("SELECT COUNT(*) FROM void_list WHERE Void_ID = %s", (void_id,))
                                    if self.mycursor.fetchone()[0] == 0:
                                        break
                                    void_id = generate_void_id()

                                # Get current date and time
                                date_voided = QDate.currentDate().toString("yyyy-MM-dd")
                                time_voided = QTime.currentTime().toString("hh:mm:ss")

                                # Log the voided item information in the void_list table
                                self.mycursor.execute("""
                                    INSERT INTO void_list (Void_ID, user_id, item_list_id, date_voided, time_voided)
                                    VALUES (%s, %s, %s, %s, %s) 
                                """, (void_id, user_id, item_list_id, date_voided, time_voided))
                                self.mydb.commit()

                                # Update product_status to 'voided' in Item_List table
                                self.mycursor.execute("""
                                    UPDATE Item_List
                                    SET product_status = 'voided'
                                    WHERE item_list_id = %s
                                """, (item_list_id,))
                                self.mydb.commit()

                                # Delete the voided item from Item_List table
                                self.mycursor.execute("""
                                    DELETE FROM Item_List
                                    WHERE product_status = 'voided'
                                """)
                                self.mydb.commit()

                                # Generate PDF with voided item information
                                pdf_path = f"voided_items_{void_id}.pdf"
                                c = canvas.Canvas(pdf_path, pagesize=letter)
                                c.drawString(100, 750, "Voided ID: {}".format(void_id))
                                c.drawString(100, 730, "Voided By: {} {}".format(status, first_name))
                                c.drawString(100, 710, "Item Voided: {}".format(product_name))
                                c.drawString(100, 690, "Date Voided: {}".format(date_voided))
                                c.drawString(100, 670, "Time Voided: {}".format(time_voided))
                                c.save()

                                # Remove row from GUI
                                self.Dashboard_Table.removeRow(selected_row)
                                self.update_total_price()
                                self.calculate_total()
                            else:
                                QMessageBox.warning(self, "Error", "Selected item not found in the database.")

                        except mysql.connector.Error as err:
                            print("Error:", err)

                # Clear selection after processing void action for all selected items
                self.Dashboard_Table.clearSelection()
        else:
            self.showMessageBox1("Please select items to void.", "No item selected")

        # Disable multi-selection in the QTableWidget
        self.Dashboard_Table.setSelectionMode(QAbstractItemView.SingleSelection)
            


            
        self.check_permissions()
        

    def check_permissions(self):
        # Fetch the current user's uid
        self.mycursor.execute("SELECT user_id FROM accountmanagement WHERE activity = 'ONLINE'")
        result = self.mycursor.fetchone()
        if result:
            # Fetch the permissions for the current user
            self.mycursor.execute("SELECT * FROM permissions WHERE user_id = %s", result)
            result_permission = self.mycursor.fetchone()
            if result_permission:
                # Make sure the permissions tuple has at least 5 elements
                if len(result_permission) >= 5:
                    # Disable buttons based on permissions
                    self.Search_Button.setEnabled(result_permission[1] != 0)
                    self.Void_Button.setEnabled(result_permission[2] != 0)
                    self.AM_Button.setEnabled(result_permission[3] != 0)
                    self.Manager_Tools.setEnabled(result_permission[4] != 0)
        
        

    def update_total_price(self):
        total_price = 0.0
        for row in range(self.Dashboard_Table.rowCount()):
            quantity_item = self.Dashboard_Table.item(row, 1)
            price_item = self.Dashboard_Table.item(row, 2)
            if quantity_item and price_item:
                try:
                    quantity = float(quantity_item.text())
                    price_text = price_item.text().replace('₱', '')  # Remove currency symbol
                    price = float(price_text)
                    total_price += quantity * price
                except ValueError as e:
                    print(f"ValueError: {e}, skipping row {row}")

        self.Price_Label.setText(f"₱{total_price:.2f}")
    
    def showMessageBox1(self, message, title):
        msg_box = QMessageBox() 
        msg_box.setStyleSheet("background-color: None; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.setIcon(QMessageBox.Warning)
        msg_box.exec_()


    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: None; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg_box.setDefaultButton(QMessageBox.No)
        msg_box.setIcon(QMessageBox.Warning)
        return msg_box.exec_()
    

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    dashboard_ui = Ui_dashboard()
    dashboard_ui.show()

    sys.exit(app.exec_())
