from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys, time, os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/intro.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)

class Ui_Intro(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_Intro, self).__init__()
        uic.loadUi(UI, self)

        self.setWindowFlags(Qt.CustomizeWindowHint | Qt.FramelessWindowHint)
        
        self.opacity_effect = QGraphicsOpacityEffect() 
  
        # setting opacity level 
        self.opacity_effect.setOpacity(1) 
  
        # adding opacity effect to the label 
        self.label.setGraphicsEffect(self.opacity_effect)

        # Set up timer for updating progress
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fade_in)
        self.increment = 0
        self.timer.start(20)  # Update every 100 milliseconds

    def fade_in(self):
        self.increment += 0.025
        self.opacity_effect.setOpacity(float(self.increment))
        self.label.setGraphicsEffect(self.opacity_effect)
        if self.increment >= 1:
            self.timer.stop()
            self.hold()

    def hold(self):
        self.timer2 = QTimer(self)
        time.sleep(1)
        self.timer2.start(5)
        self.timer2.timeout.connect(self.fade_out)

    def fade_out(self):
        
        self.increment -= 0.05
        self.opacity_effect.setOpacity(float(self.increment))
        self.label.setGraphicsEffect(self.opacity_effect)
        if self.increment <= 0:
            self.timer2.stop()
            self.openLogin()
            self.close()

    

    def openLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()

   
    
            

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Intro()
    window1.show()
    sys.exit(app.exec_())  
