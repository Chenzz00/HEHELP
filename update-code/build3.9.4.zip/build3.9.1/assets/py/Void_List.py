from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
UI = r"assets\ui\Void.ui"
import bggg
class Ui_Void_List(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Void_List, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        self.pushButton_3.clicked.connect(self.backToMTools)
        
    def backToMTools(self):
        from Manager_tools import Ui_manager_tools
        self.mTools = Ui_manager_tools()
        self.mTools.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToMTools()  
            else:
                event.ignore()
        else:
            event.accept()
    
    
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Void_List()
    window1.show()
    sys.exit(app.exec_())  