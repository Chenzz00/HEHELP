import mysql.connector
from mysql.connector import errorcode

#GENERAL DATABASE CREATOR
class database:

    def __init__(self):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "atillopobletedeleon@674647",
            port = 3306
        )
        self.mycursor = self.mydb.cursor()

    def create_db(self):
        try:
            self.mycursor.execute("CREATE DATABASE GeneralDatabase")
            self.mydb = mysql.connector.connect(database = "generaldatabase", port = 3306)
            return "Database is succesfully created"

        except mysql.connector.Error as err:
            return err

    def create_table(self, id = None):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "atillopobletedeleon@674647",
            database = "generaldatabase",
            port = 3306
        )
        self.mycursor = self.mydb.cursor()
        if id == 0:
            try:
                self.mycursor.execute("CREATE TABLE accountmanagement(username VARCHAR(255), password VARCHAR(255), status VARCHAR(255), last_updated TIMESTAMP, first_name VARCHAR(255), last_name VARCHAR(255))")
                self.sql_query = "INSERT INTO accountmanagement (username, password, status) VALUES (%s, %s, %s)"
                self.value = ("admin", "admin", "OWNER")
                self.mycursor.execute(self.sql_query, (self.value))
                self.mydb.commit()
                return "Table successfully created"
            except mysql.connector.Error as err:
                print(err)
        else:
            return "TABLE ALREADY CREATED"

    def reset_db(self):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "atillopobletedeleon@674647",
            database = "generaldatabase",
            port = 3306
        )
        self.mycursor = self.mydb.cursor()
        try:
            self.mycursor.execute("DROP DATABASE generaldatabase")
            return "DATABASE SUCCESSFULLY DROPPED"
        
        except mysql.connector.Error as err:
            print(err)

    def reset_table(self, id):
        if id == 0:
            try:
                self.mycursor.execute("DROP TABLE accountmanagement")
                return "Table Successfully Dropped"

            except mysql.connector.Error as err:
                print(err)



'''WARNING: 
RUNNING THIS SCRIPT WILL DEFINITELY OBLITERATE YOUR SAVE IN DATABASE. 
DO NOT RUN THIS SCRIPT AS MAIN IF YOU DONT WANT THAT'''
if __name__ == "__main__":
    DB = database()
    print(DB.reset_db())
    print(DB.reset_table(0))
    print(DB.create_db())
    print(DB.create_table(0))
