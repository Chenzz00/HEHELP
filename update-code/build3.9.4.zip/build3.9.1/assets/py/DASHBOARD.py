from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import os
import bggg


# Import UI files
UI_DASHBOARD = r"assets\ui\Dashboard.ui"

class Ui_dashboard(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_dashboard, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  
        self.pushButton_2.clicked.connect(self.openSearch)
        #self.pushButton_3.clicked.connect(self.openCheckOut)
        #self.pushButton_4.clicked.connect(self.openManagerTools)
        self.update_time()

    def openSearch(self):
        from searching import Ui_searching
        self.window = Ui_searching()  
        self.window.setWindowModality(Qt.ApplicationModal) 
        self.window.show()
        self.hide()
        
    def openCheckOut(self):
        from Checkout import Ui_checkout
        self.checkout = Ui_checkout()
        self.checkout.setWindowModality(Qt.ApplicationModal)
        self.checkout.show()
        self.hide()
        
    def openManagerTools(self):
        from Manager_tools import Ui_manager_tools
        self.managertools = Ui_manager_tools()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.hide()

    def update_time(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        time_text = current_time.toString("hh:mm:ss AP")
        date_text = current_date.toString("MM/dd/yy")
        self.label.setText(f"{time_text}  {date_text}")
        font = self.label.font()
        font.setPointSize(19)  
        self.label.setFont(font)

    def backToLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()

    def login_account(self, firstname, status):
        self.label_4.setText(f"WELCOME {firstname.upper()}! USER ROLE: {status}")

    def closeEvent(self, event):
        if event.spontaneous():
            from logout import Ui_logout
            self.close_dialog = Ui_logout()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                self.backToLogin()
                event.accept()
                
            else:
                event.ignore()
        else:
            event.accept()

    
    
            
            




    def openDashboard(self, username, password, role):
        # Add logic to verify login details and open dashboard
        if username == "admin" and password == "admin" and role == "admin":  # Example verification logic
            self.show()  # Show the dashboard window
import res
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_dashboard()
    window.show()

    sys.exit(app.exec_())
