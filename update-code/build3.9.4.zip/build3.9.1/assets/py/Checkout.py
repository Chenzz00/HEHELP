from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QDialog
from PyQt5.QtCore import Qt
import sys
from PyQt5.QtGui import *
import bggg
UI = r"assets\ui\Checkout.ui"

class Ui_checkout(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_checkout, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        self.pushButton.clicked.connect(self.backtoDashboard)
        

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backtoDashboard()
                
            else:
                event.ignore()
        else:
            event.accept()


    def backtoDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_checkout()
    window1.show()
    sys.exit(app.exec_())
