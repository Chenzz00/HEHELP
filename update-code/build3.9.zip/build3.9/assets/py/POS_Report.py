from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"assets\ui\POS_Report.ui"

class Ui_POS_Report(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_POS_Report, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        
    def backToMTools(self):
        from Manager_tools import Ui_manager_tools
        self.Mtools = Ui_manager_tools()
        self.Mtools.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                self.backToMTools()
                event.accept()
                
            else:
                event.ignore()
        else:
            event.accept()
  
  

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_POS_Report()
    window1.show()
    sys.exit(app.exec_())
