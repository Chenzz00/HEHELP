finalized folder structure. wag na mag bura as masisira yung integrity ng code xd.

add nalang sa respective folders yung mga idadagdag.

pag mag uupdate, rename nalang yung folder na nagcocontain ng file na to. DANKS


NOTES:
yung mga nasa to be fixed, either unknown or literal na to be fixed pa.

if may error sa directory doblehin nyo lang yung '\'

aadjust ko pa designs sa future builds

replace nyo sa designer yung build num

-milan