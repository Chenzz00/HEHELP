import mysql.connector
from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from close import Ui_close
import sys

UI = r"assets\ui\Modify_Account.ui"

class Ui_Register(QtWidgets.QWidget):

    def __init__(self):
        super(Ui_Register, self).__init__()
        uic.loadUi(UI, self)
        self.pushButton.clicked.connect(self.closeWindow)
        self.pushButton_2.clicked.connect(self.modify_account)
        self.lineEdit.textChanged.connect(self.check_inputs)
        self.lineEdit_2.textChanged.connect(self.check_inputs)
        self.lineEdit_3.textChanged.connect(self.check_inputs)
        self.lineEdit_4.textChanged.connect(self.check_inputs)
        self.lineEdit_5.textChanged.connect(self.check_inputs)
        self.connect_db()
        self.check_inputs()  # Check inputs initially

    def closeWindow(self):
        self.close()

    def check_inputs(self):
        if self.lineEdit.text() != "" and self.lineEdit_2.text() != "" and self.lineEdit_3.text() != "" and self.lineEdit_4.text() != "" and self.lineEdit_5.text() != "":
            self.pushButton_2.setEnabled(True)
        else:
            self.pushButton_2.setEnabled(False)
            


    def connect_db(self):
        try:
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="atillopobletedeleon@674647",
                database="generaldatabase"
            )
            self.mycursor = self.mydb.cursor()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def modify_account(self):
        try:
            first_name = self.lineEdit_5.text()
            last_name = self.lineEdit_4.text()
            new_username = self.lineEdit.text()
            initial_password = self.lineEdit_2.text()            
            new_password = self.lineEdit_3.text()
            if initial_password == new_password:
                update_query = "UPDATE accountmanagement SET username = %s, password = %s, first_name = %s, last_name = %s WHERE username = 'admin' AND status = 'OWNER'"
                self.mycursor.execute(update_query, (new_username, new_password, first_name, last_name))
                self.mydb.commit()
                #self.label_6.setText("Admin account successfully updated")
                #self.label_6.setStyleSheet("color: green;")
                #QTimer.singleShot(3000, self.clear_message)
                #self.accountUpdated.emit(new_username, new_password)  # Emit signal with new username and password
                self.comboBox_2.setCurrentIndex(0)
                self.comboBox_2.setEnabled(True)
                self.saveAccount()
            else:
                self.errorMessage("Password does not match.")
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorMessage(self, text):
        QtWidgets.QMessageBox.critical(None, "Error", text)

    def clear_message(self):
        self.lineEdit.clear()
        self.lineEdit_2.clear()
        self.lineEdit_3.clear()
        
    def updateAdminAccount(self, new_username, new_password):
        global mydb
        try:
            mycursor = mydb.cursor()

            # Update the admin account
            update_query = "UPDATE accountmanagement SET username = %s, password = %s WHERE username = 'admin' AND status = 'OWNER'"
            mycursor.execute(update_query, (new_username, new_password))

            mydb.commit()
            
            self.showMessageBox("Admin account updated successfully.", "Success")
        except mysql.connector.Error as err:
            self.showMessageBox((err.errno, err.sqlstate, err.msg), "ERROR")
            
    def new_account(self):
        self.comboBox_2.setCurrentIndex(2)
        self.comboBox_2.setEnabled(False)

    def saveAccount(self): 
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()
    
    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + f"{sqlstate}"
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_Register()
    window.show()

    sys.exit(app.exec_())