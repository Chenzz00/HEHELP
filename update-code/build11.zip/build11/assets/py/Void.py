from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import os
import subprocess
import bggg

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/Void.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)

class ClickableTableWidgetItem(QTableWidgetItem):
    def __init__(self, text):
        super(ClickableTableWidgetItem, self).__init__(text)
        self.setFlags(self.flags() | Qt.ItemIsSelectable | Qt.ItemIsEnabled)

    def __lt__(self, other):
        return self.text() < other.text()

class Ui_Void_List(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Void_List, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Invoice.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        self.Void_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # Establish a database connection
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

        self.Void_Table.itemDoubleClicked.connect(self.deselectRow)
        self.Void_Table.itemClicked.connect(self.openPDFFile)

        self.Search_Invoice.textChanged.connect(self.filterTableByInvoice)
        self.Filter_User.currentIndexChanged.connect(self.filterUser)
        self.Filter_Date.dateChanged.connect(self.filterTableByDate)
        self.populate_dashboard_table(filtering=False)

    def filterTableByDate(self, date):
        selected_date = date.toPyDate()
        query = """
            SELECT vl.void_id, am.first_name, am.status, vl.date_voided, vl.time_voided
            FROM Void_List vl
            INNER JOIN accountmanagement am ON vl.user_id = am.user_id
            WHERE vl.date_voided = %s
        """
        self.mycursor.execute(query, (selected_date,))
        data = self.mycursor.fetchall()
        self.update_table(data)

    def filterTableByInvoice(self, text):
        text = text.lower()
        for row in range(self.Void_Table.rowCount()):
            invoice_item = self.Void_Table.item(row, 0)  # Assuming invoice number is in the first column
            if invoice_item:
                invoice_number = invoice_item.text().lower()
                if invoice_number.startswith(text):
                    self.Void_Table.setRowHidden(row, False)
                else:
                    self.Void_Table.setRowHidden(row, True)

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()
            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()

    def update_table(self, data):
        self.Void_Table.setRowCount(len(data))
        for row_number, row_data in enumerate(data):
            for column_number, value in enumerate(row_data):
                item = ClickableTableWidgetItem(str(value))  # Use ClickableTableWidgetItem
                if column_number == 0:  # Assuming the invoice number is in the first column
                    item = QTableWidgetItem(str(value))
                    item.setFlags(item.flags() | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setForeground(Qt.blue)
                    font = item.font()
                    font.setUnderline(True)
                    item.setFont(font)
                elif column_number == 4:  # Convert time to 12-hour format for the 5th column
                    time_obj = QTime.fromString(value, "HH:mm:ss")
                    value = time_obj.toString("hh:mm AP")
                    item = QTableWidgetItem(value)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)  # Make time cell non-editable

                self.Void_Table.setItem(row_number, column_number, item)

    def filterUser(self):
        selected_user = self.Filter_User.currentText()
        if selected_user == "All" or not selected_user:
            self.populate_dashboard_table(filtering=False)
        else:
            query = """
                SELECT vl.void_id, am.first_name, am.status, vl.date_voided, vl.time_voided
                FROM Void_List vl
                INNER JOIN accountmanagement am ON vl.user_id = am.user_id
                WHERE am.first_name = %s
            """
            self.mycursor.execute(query, (selected_user,))
            data = self.mycursor.fetchall()
            self.update_table(data)

    def populate_dashboard_table(self, filtering=True):
        try:
            self.mycursor.execute("SELECT DISTINCT am.first_name FROM accountmanagement am")
            first_names = self.mycursor.fetchall()

            self.Filter_User.blockSignals(True)
            self.Filter_User.clear()
            self.Filter_User.addItem("All")
            for first_name in first_names:
                self.Filter_User.addItem(first_name[0])
            self.Filter_User.blockSignals(False)

            if not filtering:
                self.mycursor.execute("""
                    SELECT vl.void_id, am.first_name, am.status, vl.date_voided, vl.time_voided 
                    FROM Void_List vl 
                    INNER JOIN accountmanagement am ON vl.user_id = am.user_id
                """)
                data = self.mycursor.fetchall()
                self.update_table(data)
            else:
                self.update_table([])  # Clear table if filtering is enabled but no filter applied

        except mysql.connector.Error as err:
            print(f"Error: {err}")

    

    def openPDFFile(self, item):
        if item.column() == 0:  # Assuming the void ID is in the first column
            void_id = item.text()  # Retrieve the void ID directly from the item
            pdf_path = f"voided_items_{void_id}.pdf"  # Update the PDF file path based on the void ID
            if os.path.exists(pdf_path):
                subprocess.Popen(["start", pdf_path], shell=True)  # Use "start" command to open the PDF file
            else:
                QMessageBox.warning(self, "File Not Found", f"Voided items PDF file for Void ID {void_id} not found.")



    def deselectRow(self, item):
        item.setSelected(False)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Void_List()
    window1.show()
    sys.exit(app.exec_())
