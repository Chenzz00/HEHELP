from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from datetime import datetime
import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.units import inch

from PyQt5 import QtGui, QtCore
import mysql.connector
from datetime import datetime
import random
import string
import sys
import os
import bggg
from DASHBOARD import Ui_dashboard

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/Checkout.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)

class Ui_checkout(QtWidgets.QMainWindow):
    refresh_dashboard = pyqtSignal()
    transaction_saved_signal = pyqtSignal()
    def __init__(self, dashboard):
        super(Ui_checkout, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Payment_Amount.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backtoDashboard)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        self.CTransaction.setShortcut(Qt.Key_Return)
        
        self.CTransaction.setEnabled(False)
        self.Payment_Amount.textChanged.connect(self.validate_payment_amount)
        self.Checkout_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Assign the dashboard object to an attribute
        self.dashboard = dashboard

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

        # Connect signals
        self.Payment_Amount.textChanged.connect(self.populate_checkoutTable)
        self.transaction_saved = False  # Add this line

        # Populate the checkout table initially
        self.populate_checkoutTable()

        self.validate_payment_amount()

    def populate_checkoutTable(self):
        try:
            # Calculate subtotal
            query = """
                SELECT SUM(i.product_quantity * m.price) AS total_price
                FROM Item_List i
                INNER JOIN masterlist m ON i.Barcode_Number = m.barcode_number
                WHERE i.product_status = 'standby'  -- Filter items by product_status
            """
            self.mycursor.execute(query)
            total_price = self.mycursor.fetchone()[0]

            # Ensure total_price is not negative
            total_price = max(total_price, 0)

            # Fetching individual items
            query_items = """
                SELECT m.product_name, i.product_quantity, m.price 
                FROM Item_List i
                INNER JOIN masterlist m ON i.Barcode_Number = m.barcode_number
                WHERE i.product_status = 'standby'  -- Filter items by product_status
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()

            self.Checkout_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    item = QTableWidgetItem(str(value))
                    self.Checkout_Table.setItem(row_number, column_number, item)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255)) 

            # Get the payment amount from Payment_Amount line edit
            payment_text = self.Payment_Amount.text()
            if payment_text:
                payment_amount = max(float(payment_text), 0)  # Ensure payment_amount is not negative
            else:
                payment_amount = 0

            # Get the selected discount from the dashboard
            discount_index = self.dashboard.Set_Discount.currentIndex()
            discount_text = self.dashboard.Set_Discount.currentText()
            if discount_index == 0:
                discount_percentage = 0  # No discount
            elif discount_index == 1:
                discount_percentage = 0.10  # 10% discount
            elif discount_index == 2:
                discount_percentage = 0.25  # 25% discount
            elif discount_index == 3:
                discount_percentage = 0.50  # 50% discount
            else:
                discount_percentage = 0  # Default to no discount for invalid index

            # Calculate discount and discounted total
            discount = total_price * discount_percentage
            discounted_total = total_price - discount
            # Ensure discounted_total is not negative
            discounted_total = max(discounted_total, 0)

            # Update the Price_Label with the total price
            first_line = f"<b>Sub-total:</b> ₱{total_price:.2f}"
            third_line = f"<b>Total:</b> ₱{discounted_total:.2f}"
            
            fourth_line = "------------"
            
            second_line = f"<b>DISCOUNT:</b> {discount_text}"

            # Calculate discount only if payment amount is greater than or equal to subtotal
            if payment_amount >= discounted_total:
                
                # Calculate change
                change = payment_amount - discounted_total
                # Ensure change is not negative
                change = max(change, 0)

            else:
                # If payment amount is less than subtotal, set discount and change to 0
                change = 0

            fifth_line = f"<b>Change:</b> ₱{change:.2f}"
                
            # Concatenate the lines into a single HTML string
            show_textEdit = f"{first_line}<br>{second_line}<br>{third_line}<br>{fourth_line}<br>{fifth_line}"
            self.textEdit.setHtml(show_textEdit)

            # Update the Change_Display line edit
            self.Change_Display.setText(f"₱{change:.2f}")

        except mysql.connector.Error as err:
            print(err)

        self.CTransaction.clicked.connect(self.save_transaction_to_history)

    

    def save_transaction_to_history(self):
        try:
            if self.transaction_saved:
                return

            current_datetime = datetime.now()
            transaction_date = current_datetime.strftime("%Y-%m-%d")
            transaction_time = current_datetime.strftime("%H:%M:%S")

            payment_amount_text = self.Payment_Amount.text()
            if not payment_amount_text:
                QMessageBox.warning(self, "Empty Payment Amount", "Please enter a payment amount.")
                return

            payment_amount = float(payment_amount_text)

            transaction_id = ''.join(random.choices(string.digits, k=5))

            user_id_query = """
                SELECT user_id 
                FROM accountmanagement 
                WHERE activity = 'ONLINE'
            """
            self.mycursor.execute(user_id_query)
            user_id = self.mycursor.fetchone()[0]

            discount_index = self.dashboard.Set_Discount.currentIndex()
            discount_text = self.dashboard.Set_Discount.currentText()
            if discount_index == 0:
                discount_id = "00000000"  # No discount
            elif discount_index == 1:
                discount_id = "11111111"  # Discount ID for 10%
            elif discount_index == 2:
                discount_id = "22222222"  # Discount ID for 25%
            elif discount_index == 3:
                discount_id = "33333333"  # Discount ID for 50%
            else:
                discount_id = "00000000"  # Default to no discount for invalid index

            text = self.textEdit.toPlainText()
            lines = text.split('\n')
            subtotal_line = lines[0].split(': ')[1]  
            subtotal = float(subtotal_line.removeprefix("₱"))

            change_line = lines[-1].split(': ')[1]  
            change = float(change_line.removeprefix("₱"))

            if discount_index == 0:
                discount_amount = 0
            else:
                discount_amount = subtotal * (float(discount_text.strip('%')) / 100)
            transaction_total = subtotal - discount_amount

            # Insert into HistoryOfPurchase table
            insert_query_history = """
                INSERT INTO HistoryOfPurchase (
                    Transaction_ID, user_id, discount_id, Transaction_Sub_Total, 
                    Transaction_Total_Change, Transaction_Total, Transaction_Date, 
                    Transaction_Time
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            self.mycursor.execute(insert_query_history, (
                transaction_id, user_id, discount_id, subtotal, change, 
                transaction_total, transaction_date, transaction_time
            ))
            self.mydb.commit()

            # Insert into TemporaryTransaction table
            insert_query_temporary = """
                INSERT INTO TemporaryTransaction (
                    Transaction_ID, user_id, Discount_ID, Transaction_Sub_Total, 
                    Transaction_Total, Transaction_Total_Change, Transaction_Date, 
                    Transaction_Time
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            self.mycursor.execute(insert_query_temporary, (
                transaction_id, user_id, discount_id, subtotal, change, 
                transaction_total, transaction_date, transaction_time
            ))
            self.mydb.commit()

            update_query = """
                UPDATE Item_List 
                SET product_status = 'purchased' 
                WHERE product_status = 'standby'
            """
            self.mycursor.execute(update_query)
            self.mydb.commit()

            # Update stock_left in masterlist table
            for row in range(self.Checkout_Table.rowCount()):
                product_name = self.Checkout_Table.item(row, 0).text()
                quantity_sold = int(self.Checkout_Table.item(row, 1).text())

                # Subtract quantity_sold from stock_left
                update_stock_query = """
                    UPDATE masterlist
                    SET stock_left = stock_left - %s
                    WHERE product_name = %s
                """
                self.mycursor.execute(update_stock_query, (quantity_sold, product_name))
                self.mydb.commit()

            pdf_file_name = f"{transaction_id}.pdf"
            c = canvas.Canvas(pdf_file_name, pagesize=letter)
            c.setFont("Helvetica", 12)

            c.drawString(100, 750, "=" * 40)
            c.drawString(100, 730, f"Transaction ID: {transaction_id}")
            c.drawString(100, 710, f"Date: {transaction_date}")
            c.drawString(100, 690, f"Time: {transaction_time}")
            c.drawString(100, 670, "=" * 40)
            c.drawString(100, 650, f"Discount: {discount_text}")
            c.drawString(100, 630, "=" * 40)
            c.drawString(100, 610, f"{'Product':<25}{'Quantity':<10}{'Price':>5}")
            c.drawString(100, 590, "=" * 40)
            y = 570
            for row in range(self.Checkout_Table.rowCount()):
                product_name = self.Checkout_Table.item(row, 0).text()
                quantity = self.Checkout_Table.item(row, 1).text()
                price = self.Checkout_Table.item(row, 2).text()
                c.drawString(100, y, f"{product_name:<25} x{quantity:<9}{price:>10}")
                y -= 20

            c.drawString(100, y, "=" * 40)
            y -= 20
            c.drawString(100, y, f"Sub Total: {subtotal:>10.2f}")
            y -= 20
            c.drawString(100, y, f"Discount: {discount_amount:>10.2f}")
            y -= 20
            c.drawString(100, y, f"Total: {transaction_total:>10.2f}")
            y -= 20
            c.drawString(100, y, f"Payment: {payment_amount:>10.2f}")
            y -= 20
            c.drawString(100, y, f"Change: {change:>10.2f}")
            y -= 20
            
            c.drawString(100, y, "=" * 40)

            c.save()
            
            self.showMessageBox("Transaction successful! Details have been saved to HistoryOfPurchase.", "Transaction Successfully")
            

            self.transaction_saved = True

            # Emit the signal to indicate that the transaction is saved
            self.transaction_saved_signal.emit()

            self.open_dashboard()

        except mysql.connector.Error as err:
            print("MySQL Error:", err)
            QMessageBox.warning(self, "Error", f"Failed to save transaction: {err}")





    def validate_payment_amount(self):
       
        payment_text = self.Payment_Amount.text()

    
        self.CTransaction.setEnabled(False)

        first_line_text = self.textEdit.toPlainText().split('\n')[2]
        total = float(first_line_text.split(': ')[1].removeprefix("₱"))
        try:
            payment_amount = float(payment_text)
            if payment_amount >= total:
                self.CTransaction.setEnabled(True)
        except ValueError:
            pass
       

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backtoDashboard()
                
            else:
                event.ignore()
        else:
            event.accept()

    def open_dashboard(self):
        self.window = Ui_dashboard()
        self.window.show()
        self.close()

    def backtoDashboard(self):
        self.dashboard.show()
        self.close()

    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: None; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    dashboard = Ui_dashboard()
    window1 = Ui_checkout(dashboard)  # Pass the dashboard object to Ui_checkout
    window1.show()
    sys.exit(app.exec_())
