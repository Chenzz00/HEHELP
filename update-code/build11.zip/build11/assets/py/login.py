from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import Database
import mysql.connector
import sys
import bggg
import os 

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/LOGINUI.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
sys.path.append(login_module_path)
sys.path.append(ui_path)

class Ui_login(QtWidgets.QMainWindow):

    def __init__(self):
        super(Ui_login, self).__init__()
        uic.loadUi(UI, self)

        self.mydb = mysql.connector.connect(
            host = "localhost", 
            user = "root", 
            passwd = "CPET8L", 
            database = "generaldatabase", 
            port = 3306)
        self.mycursor = self.mydb.cursor()

        self.Username.setValidator(None)
        self.Password.setValidator(None)
        self.Login_Button.clicked.connect(self.validateLogin)
        self.Login_Button.setAutoDefault(True) 
        self.Login_Button.setDefault(True)  

        self.Login_Button.setShortcut(Qt.Key_Return)
        

        self.Username.setFocus()
        self.Username.setFocusPolicy(Qt.StrongFocus)
        self.Password.setFocusPolicy(Qt.StrongFocus)

        self.reset_login()
        

    def validateLogin(self):
        username = self.Username.text()
        password = self.Password.text()
        selected_status = self.Role.currentText() 

        try:
            sql_query = "SELECT * FROM accountmanagement WHERE username = %s AND password = %s AND status = %s"
            self.mycursor.execute(sql_query, (username, password, selected_status))
            self.result = self.mycursor.fetchone()  

            if self.result:  
                db_status = self.result[3]
                if self.result[1] == "admin" and self.result[2] == "admin" and selected_status == "OWNER":
                    self.is_new_account = True
                    self.open_ModifyAccount()
                    self.showMessageBox("Please set up your owner account.", "Setup")
                    self.close()
                
                #TODO EMIT DATA TO OTHER MODULES
                elif db_status == selected_status:
                    syntax = 'UPDATE accountmanagement SET activity = "ONLINE" WHERE username = %s AND password = %s AND status = %s'
                    values = (username, password, selected_status)
                    self.mycursor.execute(syntax, values)
                    self.mydb.commit()
                    self.openDashboard()
                    self.close()
                else:
                    self.showMessageBox("Invalid username, password, or user role.", "Login Failed")
            else:
                self.showMessageBox("Invalid username, password, or user role.", "Login Failed")

        except mysql.connector.Error as err:
            print("Error:", err)

    
    def reset_login(self):
        syntax = 'UPDATE accountmanagement SET activity = "OFFLINE" WHERE activity = "ONLINE"'
        self.mycursor.execute(syntax)
        self.mydb.commit()

    

    def openDashboard(self):
        from DASHBOARD import Ui_dashboard
        from searching import Ui_searching
        self.ui = Ui_dashboard()
        self.ui.setWindowModality(Qt.ApplicationModal)
        self.ui.show()
        
        self.search_ui = Ui_searching(user_id=self.result[0])  
        


    def openIntro(self):
        from intro import Ui_Intro
        self.intro = Ui_Intro()
        self.intro.show()


    def open_ModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        if self.is_new_account == True:
            self.window.setup(0)
            self.is_new_account = False  
        self.window.show()


    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: None; color: rgba(0, 0, 0, 255);")
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        
        # Set standard warning icon
        msg_box.setIcon(QMessageBox.Warning)
        
        msg_box.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    login_ui = Ui_login()
    login_ui.show()
    sys.exit(app.exec_())
