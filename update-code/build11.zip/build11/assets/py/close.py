from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys, os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Define paths relative to the script location
UI = resource_path('assets/ui/close.ui')
login_module_path = resource_path('assets/py')
ui_path = resource_path('assets/ui')
images_path = resource_path('assets/image')
sys.path.append(login_module_path)
sys.path.append(ui_path)


class Ui_close(QtWidgets.QDialog):
    closeConfirmed = pyqtSignal()
    def __init__(self):
        super(Ui_close, self).__init__()
        uic.loadUi(UI, self)

        self.pushButton.installEventFilter(self)
        self.pushButton_2.installEventFilter(self)
        self.pushButton.clicked.connect(self.on_accept)
        self.pushButton_2.clicked.connect(self.reject)

    def set_image(self, image_path):
        pixmap = QPixmap(image_path)
        self.label_3.setPixmap(pixmap)

    def eventFilter(self, object, event):
        if object == self.pushButton:
            if event.type() == QEvent.Enter:
                self.set_image("assets\image\cry.jpg")
                self.stop = True
                return True
            elif event.type() == QEvent.Leave:
                self.set_image("assets\image\ponder.jpg")
                self.stop = False
                
            return False
        elif object == self.pushButton_2:
            if event.type() == QEvent.Enter:
                self.set_image("assets\image\happy.jpg")
                self.stop = True
                return True
            elif event.type() == QEvent.Leave:
                self.set_image("assets\image\ponder.jpg")
                self.stop = False
            return False
        else:
            print("gay")

    def on_accept(self):
        # Emit the custom signal
        self.closeConfirmed.emit()
        self.accept()
    
    def change_mood(self):
        pass
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_close()
    window1.exec_()
    sys.exit(app.exec_())
