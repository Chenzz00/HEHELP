CREATE TABLE users (
    username VARCHAR(255),
    password VARCHAR(255),
    status VARCHAR(255)
);