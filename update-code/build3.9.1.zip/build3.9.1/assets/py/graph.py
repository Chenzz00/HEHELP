from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel
from PyQt5.QtCore import Qt
import sys
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np

UI = r"assets/ui/graph.ui"

class Ui_graph(QMainWindow):
    def __init__(self):
        super(Ui_graph, self).__init__()
        uic.loadUi(UI, self)

        # Create the plot
        self.fig, self.ax = plt.subplots(figsize=(10, 6))  # Increasfrom PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel
from PyQt5.QtCore import Qt
import sys
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np

UI = r"assets/ui/graph.ui"

class Ui_graph(QMainWindow):
    def __init__(self):
        super(Ui_graph, self).__init__()
        uic.loadUi(UI, self)

        # Create the plot
        self.fig, self.ax = plt.subplots()
        self.months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November']
        
        # Shuffle the sales data to make it unordered
        self.sales = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000]
        np.random.shuffle(self.sales)

        self.ax.bar(self.months, self.sales)
        self.ax.set_xlabel('Months')
        self.ax.set_ylabel('Sales')
        self.ax.set_title('Sales Graph')

        # Create the FigureCanvas widget
        self.canvas = FigureCanvas(self.fig)

        # Create a QVBoxLayout for the central widget
        self.layout = QVBoxLayout(self.centralwidget)
        self.centralwidget.setLayout(self.layout)

        # Add the canvas to the layout
        self.layout.addWidget(self.canvas)

        # Create a QLabel to act as the custom tooltip
        self.tooltip_label = QLabel(self)
        self.tooltip_label.setStyleSheet("background-color: gray; border: 1px solid black; color: white;")
        self.tooltip_label.setFixedHeight(30)
        self.tooltip_label.setAlignment(Qt.AlignCenter)
        self.tooltip_label.hide()  # Initially hidden

        # Add the tooltip label to the layout
        self.layout.addWidget(self.tooltip_label)

        # Connect the mouse click event to a function
        self.cid = self.canvas.mpl_connect('button_press_event', self.on_click)

    def resizeEvent(self, event):
        # Adjust the size of the canvas when the window is resized
        self.canvas.draw()

    def on_click(self, event):
        # Get the x coordinate of the mouse click
        x = event.xdata
        y = event.ydata

        if x is not None and y is not None:
            # Find the index of the nearest x value in the months list
            index = int(np.round(x))

            # Ensure the index is within bounds
            if 0 <= index < len(self.sales):
                # Get the corresponding month and sales value
                month = self.months[index]
                sales = self.sales[index]

                # Update the tooltip label text
                self.tooltip_label.setText(f"Sales for {month}: {sales}")

                # Move the tooltip label to the click position
                tooltip_x = int(event.guiEvent.x())
                tooltip_y = int(event.guiEvent.y())
                self.tooltip_label.move(tooltip_x, tooltip_y)

                # Adjust the size of the label to fit the text
                self.tooltip_label.adjustSize()

                # Show the tooltip label
                self.tooltip_label.show()
            else:
                # Hide the tooltip if clicked outside valid range
                self.tooltip_label.hide()
        else:
            # Hide the tooltip if click is outside plot area
            self.tooltip_label.hide()

app = QApplication(sys.argv)
window1 = Ui_graph()
window1.show()
sys.exit(app.exec_())
e the figure size
        self.months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November']
        
        # Shuffle the sales data to make it unordered
        self.sales = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000]
        np.random.shuffle(self.sales)

        self.ax.bar(self.months, self.sales)
        self.ax.set_xlabel('Months')
        self.ax.set_ylabel('Sales')
        self.ax.set_title('Sales Graph')

        # Rotate the x-axis labels for better readability
        self.ax.set_xticklabels(self.months, rotation=45, ha='right')

        # Create the FigureCanvas widget and add it to the layout
        self.canvas = FigureCanvas(self.fig)

        # Assuming 'centralwidget' is the widget you want to place the canvas in
        self.centralwidget = self.findChild(QWidget, 'centralwidget')
        self.layout = QVBoxLayout(self.centralwidget)
        self.layout.addWidget(self.canvas)

        # Create a QLabel to act as the custom tooltip
        self.tooltip_label = QLabel(self)
        self.tooltip_label.setStyleSheet("background-color: gray; border: 1px solid black; color: white;")
        self.tooltip_label.setFixedHeight(30)
        self.tooltip_label.setAlignment(Qt.AlignCenter)
        self.tooltip_label.hide()  # Initially hidden

        # Connect the mouse click event to a function
        self.cid = self.canvas.mpl_connect('button_press_event', self.on_click)

    def on_click(self, event):
        # Get the x coordinate of the mouse click
        x = event.xdata
        y = event.ydata

        if x is not None and y is not None:
            # Find the index of the nearest x value in the months list
            index = int(np.round(x))

            # Ensure the index is within bounds
            if 0 <= index < len(self.sales):
                # Get the corresponding month and sales value
                month = self.months[index]
                sales = self.sales[index]

                # Update the tooltip label text
                self.tooltip_label.setText(f"Sales for {month}: {sales}")

                # Move the tooltip label to the click position
                tooltip_x = int(event.guiEvent.x())
                tooltip_y = int(event.guiEvent.y())
                self.tooltip_label.move(tooltip_x, tooltip_y)

                # Adjust the size of the label to fit the text
                self.tooltip_label.adjustSize()

                # Show the tooltip label
                self.tooltip_label.show()
            else:
                # Hide the tooltip if clicked outside valid range
                self.tooltip_label.hide()
        else:
            # Hide the tooltip if click is outside plot area
            self.tooltip_label.hide()

app = QApplication(sys.argv)
window1 = Ui_graph()
window1.show()
sys.exit(app.exec_())
