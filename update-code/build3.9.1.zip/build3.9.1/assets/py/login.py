from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import database
import mysql.connector
import sys


'''NOTE: THIS SCRIPT IS LIKE 95% COOL. JUST NEED TO FIND MORE BETTER WAYS TO RUN THE SCRIPT''' 

UI_LOGIN = r"assets\ui\LOGINUI.ui"

#creates database on startup. ignored if database exists.
startup = database()
startup.create_db()
startup.create_table(0)
mydb = startup.mydb

class Ui_login(QtWidgets.QMainWindow):
    loginSuccessful = QtCore.pyqtSignal(str, str, str) 

    def __init__(self):
        super(Ui_login, self).__init__()
        uic.loadUi(UI_LOGIN, self)

        self.lineEdit.setValidator(None)
        self.lineEdit_2.setValidator(None)
        self.pushButton_2.clicked.connect(self.reset_owner)
        self.pushButton.clicked.connect(self.validateLogin)
        self.pushButton.setAutoDefault(True) 
        self.pushButton.setDefault(True)  

        self.pushButton.setShortcut(Qt.Key_Return)

        self.lineEdit.setFocus()
        self.lineEdit.setFocusPolicy(Qt.StrongFocus)
        self.lineEdit_2.setFocusPolicy(Qt.StrongFocus)


    def validateLogin(self):
        username = self.lineEdit.text()
        password = self.lineEdit_2.text()
        selected_status = self.comboBox.currentText() 

        try:
            global mydb
            mycursor = mydb.cursor()

            sql_query = "SELECT * FROM accountmanagement WHERE username = %s AND password = %s"
            mycursor.execute(sql_query, (username, password))
            self.result = mycursor.fetchone()  

            if self.result:  
                db_status = self.result[2]
                if self.result[0] == "admin" and self.result[1] == "admin" and selected_status == "OWNER":
                    self.is_new_account = True
                    self.open_ModifyAccount()
                    self.showMessageBox("Please set up your owner account.", "Setup")
                    self.close()
                    
                elif db_status == selected_status:
                    self.loginSuccessful.emit(username, password, db_status)
                    self.openDashboard()
                    self.close()
                else:
                    self.showMessageBox("Invalid username, password, or user role.", "Login Failed")
            else:
                self.showMessageBox("Invalid username, password, or user role.", "Login Failed")

        except mysql.connector.Error as err:
            print("Error:", err)

    #TEST ONLY. DELETE WHEN SOFTWARE IS FINISHED
    def reset_owner(self):
        global mydb
        try:
            syntax = 'DELETE FROM accountmanagement WHERE status = "OWNER"'
            self.resetOwner = mydb.cursor()
            self.resetOwner.execute(syntax)
            mydb.commit()
            self.sql_query = "INSERT INTO accountmanagement (username, password, status) VALUES (%s, %s, %s)"
            self.value = ("admin", "admin", "OWNER")
            self.resetOwner.execute(self.sql_query, (self.value))
            mydb.commit()
            print("Successfully reset")


        except mysql.connector.Error as err:
            self.showMessageBox((err.errno, err.sqlstate, err.msg), "ERROR")


    def openDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.ui = Ui_dashboard()
        self.ui.setWindowModality(Qt.ApplicationModal)
        print(self.result) 
        self.ui.login_account(self.result[4],self.result[2])
        self.ui.show()


    def openIntro(self):
        from intro import Ui_Intro
        self.intro = Ui_Intro()
        self.intro.show()


    def open_ModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        if self.is_new_account == True:
            self.window.setup(0)
            self.is_new_account = False  
        self.window.show()


    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: white; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.exec_()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_login()
    window1.show()
    sys.exit(app.exec_())
