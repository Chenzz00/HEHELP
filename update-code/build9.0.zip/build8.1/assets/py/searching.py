from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import Database
from Quantity import Ui_Quantity
import mysql.connector
import sys
import bggg
import random
import string
UI = r"assets\ui\Searching.ui"

class Ui_searching(QtWidgets.QMainWindow):
    productSelected = pyqtSignal(str, float, int)
    
    def __init__(self,user_id=None):
        super(Ui_searching, self).__init__()
        uic.loadUi(UI, self)
        self.user_id = user_id 
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Barcode.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Cart_Button.clicked.connect(self.showQuantityDialog)
        self.Cart_Button.setShortcut(Qt.Key_Return)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        self.Search_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.Search_Barcode.textChanged.connect(self.searchBarcode)
        
        self.mydb = mysql.connector.connect(
            host="localhost", 
            user="root", 
            passwd="CPET8L", 
            database="generaldatabase", 
            port=3306)
        self.mycursor = self.mydb.cursor()

        self.update_table()
        self.Search_Table.itemDoubleClicked.connect(self.clearSelection)  # Connect double-click event

    def update_table(self, data=None):
        try:
            if data is None:
                self.mycursor.execute("SELECT barcode_number, product_name, category, price  FROM masterlist")
                data = self.mycursor.fetchall()
            
            self.Search_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    self.Search_Table.setItem(row_number, column_number, QTableWidgetItem(str(value)))
        
        except mysql.connector.Error as err:
            print(err)

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def clearSelection(self):
        self.Search_Table.clearSelection()  # Clear table selection

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()

    def searchBarcode(self, barcode):
        try:
            query = "SELECT barcode_number, product_name, category, price FROM masterlist WHERE barcode_number LIKE %s"
            self.mycursor.execute(query, (f"{barcode}%",))  
            result = self.mycursor.fetchall()
            self.update_table(result)
        except mysql.connector.Error as err:
            print(err)

    def showQuantityDialog(self):
        selected_item = self.Search_Table.selectedItems()
        if selected_item:
           
            barcode = selected_item[0].text()
            self.quantity_dialog = Ui_Quantity()
            self.quantity_dialog.quantityAdded.connect(lambda quantity: self.addProductToCart(barcode, quantity))
            self.quantity_dialog.setWindowModality(Qt.WindowModal) 
            self.quantity_dialog.show()
        else:
            self.showMessageBox1("Please select an item", "Warning")
            

    def generate_random_6_digit_number(self):
        return ''.join(random.choices(string.digits, k=6))
    
    def addProductToCart(self, barcode, quantity):
        try:
            if quantity <= 0:
                product_status = 'Voided'
            else:
                product_status = 'Standby'

            # Check if the product already exists in the cart
            self.mycursor.execute("""
                SELECT item_list_id, product_quantity, product_status 
                FROM Item_List 
                WHERE Barcode_Number = %s AND product_status = 'Standby'
            """, (barcode,))
            existing_row = self.mycursor.fetchone()

            if existing_row:
                # If the product is already in the cart and its status is 'Standby', update its quantity
                new_quantity = existing_row[1] + quantity
                if new_quantity > 0:
                    self.mycursor.execute("""
                        UPDATE Item_List 
                        SET product_quantity = %s 
                        WHERE item_list_id = %s
                    """, (new_quantity, existing_row[0]))
                    self.mydb.commit()
                    print("Quantity updated in TemporaryTransaction successfully")
                else:
                    # If the quantity becomes zero or negative, remove the item from the cart
                    self.mycursor.execute("DELETE FROM Item_List WHERE item_list_id = %s", (existing_row[0],))
                    self.mydb.commit()
                    print("Item removed from TemporaryTransaction successfully")
            else:
                # If the product does not exist in the cart or its status is not 'Standby', add it as a new row
                product_list_id = self.generate_random_6_digit_number()
                self.mycursor.execute("""
                    INSERT INTO Item_List (item_list_id, Barcode_Number, product_quantity, product_status) 
                    VALUES (%s, %s, %s, %s)
                """, (product_list_id, barcode, quantity, product_status))
                self.mydb.commit()
                print("Item added to TemporaryTransaction successfully")

        except mysql.connector.Error as err:
            print(err)



    def showMessageBox1(self, message, title):
        msg_box = QMessageBox() 
        msg_box.setStyleSheet("background-color: None; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.setIcon(QMessageBox.Warning)
        msg_box.exec_()








if __name__ == "__main__":
    app = QApplication(sys.argv)
    searching_window = Ui_searching()
    searching_window.show()
    sys.exit(app.exec_())