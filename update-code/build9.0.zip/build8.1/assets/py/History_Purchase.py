from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os
import subprocess
from PyQt5.QtWidgets import QMessageBox
import bggg
UI = r"assets/ui/History_Of_Purchase.ui"

class ClickableLineEdit(QLineEdit):
    clicked = pyqtSignal()

    def mousePressEvent(self, event):
        self.clicked.emit()
        super().mousePressEvent(event)

class Ui_History_Purchase(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_History_Purchase, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_invoice.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.HOP_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

        self.HOP_Table.itemDoubleClicked.connect(self.deselectRow)
        self.Back_Button.setShortcut(Qt.Key_Escape)

        self.Search_invoice.textChanged.connect(self.filterTableByInvoice)
        self.Filter_User.currentIndexChanged.connect(self.filterUser)
        self.Filter_Date.dateChanged.connect(self.filterByDate)

        self.populate_dashboard_table(filtering=False)

    def filterByDate(self):
        selected_date = self.Filter_Date.date().toString(Qt.ISODate)
        query = """
            SELECT hp.Transaction_ID, am.first_name, hp.Transaction_Date, hp.Transaction_Time
            FROM HistoryOfPurchase hp
            INNER JOIN accountmanagement am ON hp.user_id = am.user_id
            WHERE hp.Transaction_Date = %s
        """
        self.mycursor.execute(query, (selected_date,))
        data = self.mycursor.fetchall()
        self.update_table(data)

    def filterUser(self):
        selected_user = self.Filter_User.currentText()
        if selected_user == "All" or not selected_user:
            self.populate_dashboard_table(filtering=False)
        else:
            query = """
                SELECT hp.Transaction_ID, am.first_name, hp.Transaction_Date, hp.Transaction_Time
                FROM HistoryOfPurchase hp
                INNER JOIN accountmanagement am ON hp.user_id = am.user_id
                WHERE am.first_name = %s
            """
            self.mycursor.execute(query, (selected_user,))
            data = self.mycursor.fetchall()
            self.update_table(data)

    def convert_to_12_hour_format(self, time_str):
        """Convert 24-hour format time string to 12-hour format."""
        if time_str is not None:
            try:
                time_obj = datetime.strptime(time_str, '%H:%M:%S')
                return time_obj.strftime('%I:%M %p')
            except ValueError:
                return time_str
        else:
            return ""

    def populate_dashboard_table(self, filtering=True):
        try:
            self.mycursor.execute("SELECT DISTINCT first_name FROM accountmanagement am")
            first_names = self.mycursor.fetchall()

            self.Filter_User.blockSignals(True)
            self.Filter_User.clear()
            self.Filter_User.addItem("All")
            for first_name in first_names:
                self.Filter_User.addItem(first_name[0])
            self.Filter_User.blockSignals(False)

            if not filtering:
                # Fetch all transactions without filtering
                self.mycursor.execute("""
                    SELECT hp.Transaction_ID, am.first_name, hp.Transaction_Date, hp.Transaction_Time
                    FROM HistoryOfPurchase hp
                    INNER JOIN accountmanagement am ON hp.user_id = am.user_id
                """)
                data = self.mycursor.fetchall()
                self.update_table(data)
            else:
                self.update_table([])  # Clear table if filtering is enabled but no filter applied

        except mysql.connector.Error as err:
            print(f"Error: {err}")

    def deselectRow(self, item):
        self.HOP_Table.clearSelection()

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def filterTableByInvoice(self, text):
        text = text.lower()
        for row in range(self.HOP_Table.rowCount()):
            invoice_item = self.HOP_Table.item(row, 0)  # Assuming invoice number is in the first column
            if invoice_item:
                invoice_number = invoice_item.text().lower()
                if invoice_number.startswith(text):  # This line ensures it matches from the start
                    self.HOP_Table.setRowHidden(row, False)
                else:
                    self.HOP_Table.setRowHidden(row, True)
            else:
                self.HOP_Table.setRowHidden(row, True)


    def openPDFFile(self, item):
        invoice_number = item.text()
        # Assuming the PDF file is named based on the invoice number with a '.pdf' extension
        file_path = f"{invoice_number}.pdf"
        if os.path.exists(file_path):
            subprocess.Popen([file_path], shell=True)
        else:
            QMessageBox.warning(self, "File Not Found", f"PDF file for invoice {invoice_number} not found.")
    def update_table(self, data):
        self.HOP_Table.setRowCount(len(data))
        for row_number, row_data in enumerate(data):
            for column_number, value in enumerate(row_data):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignCenter)
                if column_number == 0:  # Assuming invoice number is in the first column
                    item.setFlags(item.flags() | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                    item.setForeground(Qt.blue)
                    font = item.font()
                    font.setUnderline(True)
                    item.setFont(font)
                elif column_number == 3:  # Convert time to 12-hour format for the 4th column
                    value = self.convert_to_12_hour_format(value)
                    item.setText(value)
                self.HOP_Table.setItem(row_number, column_number, item)

        # Connect the itemClicked signal only for the first column
        self.HOP_Table.itemClicked.connect(self.on_table_item_clicked)

        # Disable selection background color for the entire table
        self.HOP_Table.setSelectionMode(QAbstractItemView.NoSelection)


    def on_table_item_clicked(self, item):
        # Check if the clicked item is in the first column
        if item.column() == 0:
            self.openPDFFile(item)

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()
                
            else:
                event.ignore()
        else:
            event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_History_Purchase()
    window1.show()
    sys.exit(app.exec_())
