from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import bggg

UI = r"assets\ui\permissions.ui"

class Ui_Permissions(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Permissions, self).__init__()
        uic.loadUi(UI, self)

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        
        self.mycursor = self.mydb.cursor()

        self.pushButton_2.clicked.connect(self.save_changes)
        self.pushButton.clicked.connect(self.close)

    def get_user_details(self, fname, lname, status, current_user_status):
        global result
        self.fname = fname
        self.lname = lname
        self.status = status
        self.current_user_status = current_user_status
        username = f"{fname} {lname}"
        self.label.setText(f"USERNAME: {username}")
        self.label_2.setText(f"ROLE: {status}")
        self.checkboxes = [self.permx, self.perm0, self.perm1, self.perm2, self.perm3, self.perm4, self.perm5, self.perm6, self.perm7, self.perm8]

        self.mycursor.execute("SELECT * FROM accountmanagement WHERE first_name = %s AND last_name = %s AND status = %s", (self.fname, self.lname, self.status))
        result = self.mycursor.fetchone()
        if result:
            user_id = result[0]

            self.mycursor.execute("SELECT * FROM permissions WHERE user_id = %s", (user_id,))
            result_permission = self.mycursor.fetchone()
            if result_permission:
                permissions = result_permission[1:]
                print(permissions)
                for checkbox, permission in zip(self.checkboxes, permissions):
                    state = int(permission)
                    checkbox.setChecked(state == 1)
                    print(f"ITERATED {checkbox} using {state}")
                    if self.current_user_status != "OWNER":
                        checkbox.setEnabled(False)
                    else:
                        checkbox.setEnabled(True)
            else:
                print("No permissions found for the user.")
        else:
            print("User not found.")

    def save_changes(self):
        global result
        self.new_permission = []
        self.checkboxes = [self.permx, self.perm0, self.perm1, self.perm2, self.perm3, self.perm4, self.perm5, self.perm6, self.perm7, self.perm8]
        for checkbox in self.checkboxes:
            if checkbox.isChecked():
                self.new_permission.append(1)
            else:
                self.new_permission.append(0)
        self.new_permission.append(result[0])
        self.permission_values = tuple(self.new_permission)
        update_query = "UPDATE permissions SET Can_search_products = %s, Can_Void_Product = %s, Can_Access_Account_Manager = %s, Can_Access_Manager_Tools = %s, Can_Access_masterlist = %s, Can_Access_Void_list = %s, Can_Access_history_purchase = %s, Can_Access_create_accounts = %s, Can_Access_delete_accounts = %s, is_blacklisted = %s WHERE user_id = %s"
        self.mycursor.execute(update_query, self.permission_values)
        self.mydb.commit()
        self.showMessageBox("Permission successfully updated.", "Success")
        self.close()

    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: white; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Permissions()
    window1.show()
    sys.exit(app.exec_())
