from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import os
import bggg
import random
import string

# Import UI files
UI_DASHBOARD = r"assets\ui\Dashboard.ui"

class Ui_dashboard(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_dashboard, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.Search_Button.clicked.connect(self.openSearch)
        self.CheckOut.clicked.connect(self.openCheckOut)
        self.Manager_Tools.clicked.connect(self.openManagerTools)
        self.AM_Button.clicked.connect(self.openAccountManagement)
        self.Void_Button.clicked.connect(self.void_selected_item)  
        self.Dashboard_Table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.Set_Discount.setEnabled(False)

        # Connect the opening of the Set_Discount combobox to the presence of data in the dashboard table
        self.Dashboard_Table.itemChanged.connect(self.enable_discount_combobox)
        
        self.update_time()

        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        
        self.mycursor = self.mydb.cursor()

        self.populate_dashboard_table()
        self.set_user()
        self.calculate_total()
    
        self.Set_Discount.currentIndexChanged.connect(self.calculate_total)  

        

    def calculate_total(self):
        try:
            subtotal = float(self.Price_Label.text().removeprefix("₱"))
        except:
            subtotal = 0.0
        first_line = "<b>SUB-TOTAL:</b> ₱{:.2f}".format(subtotal)
        second_line = f"<b>DISCOUNT:</b>" +  self.Set_Discount.currentText()
        show_textEdit = f"{first_line}<br>{second_line}"
        self.textEdit.setHtml(show_textEdit)

    def openSearch(self):
        from searching import Ui_searching
        self.window = Ui_searching()
        self.window.setWindowModality(Qt.ApplicationModal)
        self.window.show()
        self.hide()

    def openCheckOut(self):
        if self.Dashboard_Table.rowCount() == 0:
            QMessageBox.warning(self, "Empty Dashboard", "Please input items before proceeding to checkout.")
            return
        from Checkout import Ui_checkout
        self.checkout = Ui_checkout(self)
        self.checkout.setWindowModality(Qt.ApplicationModal)
        self.checkout.refresh_dashboard.connect(self.refresh_dashboard_table)
        self.checkout.show()
        self.close()
                
       
    def refresh_dashboard_table(self):
        try:
            self.populate_dashboard_table() 
            QMessageBox.information(self, "Dashboard Refreshed", "Dashboard table has been refreshed.")
        except Exception as e:
            print("Error refreshing dashboard table:", e)

    def fetch_quantity(self, quantity, user_role):
        self.quantity_label.setText(f"Quantity: {quantity}")

    def openManagerTools(self):
        from Manager_tools import Ui_manager_tools
        self.managertools = Ui_manager_tools()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.close()

    def openAccountManagement(self):
        from account_management import Ui_accountManagement
        self.accountManagement = Ui_accountManagement()
        self.accountManagement.setWindowModality(Qt.ApplicationModal)
        self.accountManagement.show()
        self.close()

    def update_time(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        time_text = current_time.toString("hh:mm:ss AP")
        date_text = current_date.toString("MM/dd/yy")
        self.DateTime_Label.setText(f"{time_text}  {date_text}")
        font = self.DateTime_Label.font()
        font.setPointSize(19)
        self.DateTime_Label.setFont(font)

    def backToLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from logout import Ui_logout
            self.close_dialog = Ui_logout()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            result = self.close_dialog.exec_()
            if result == QDialog.Accepted:
                self.backToLogin()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def set_user(self):
        try:
            syntax = 'SELECT first_name, status FROM accountmanagement WHERE activity = "ONLINE"'
            self.mycursor.execute(syntax)
            namestat = self.mycursor.fetchone()
            self.User_Label.setText(f"WELCOME {namestat[0].upper()}! USER ROLE: {namestat[1]}")
        except mysql.connector.Error as err:
            print(err)
    
    def populate_dashboard_table(self):
        try:
            # Fetch the total price of all items in the dashboard
            query_total_price = """
                SELECT SUM(il.product_quantity * m.price) AS total_price
                FROM Item_List il
                INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
            """
            self.mycursor.execute(query_total_price)
            total_price = self.mycursor.fetchone()[0] or 0
            self.Price_Label.setText(f"₱{total_price:.2f}")

            # Fetch the product_name, product_quantity, and price from the Item_List and masterlist tables
            query_items = """
                SELECT m.product_name, il.product_quantity, m.price
                FROM Item_List il
                INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
            """
            self.mycursor.execute(query_items)
            data = self.mycursor.fetchall()

            self.Dashboard_Table.setRowCount(len(data))
            for row_number, (product_name, product_quantity, price) in enumerate(data):
                # Set the product_name, product_quantity, and price in the table
                self.Dashboard_Table.setItem(row_number, 0, QTableWidgetItem(product_name))  # Product Name
                self.Dashboard_Table.setItem(row_number, 1, QTableWidgetItem(str(product_quantity)))  # Quantity
                self.Dashboard_Table.setItem(row_number, 2, QTableWidgetItem(f"₱{price:.2f}"))  # Price

                # Set background and foreground colors
                for column_number in range(3):  # Loop through columns
                    item = self.Dashboard_Table.item(row_number, column_number)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255))

            # Enable/disable the discount combo box based on whether there are items in the dashboard table
            self.enable_discount_combobox()

        except mysql.connector.Error as err:
            print(err)

    def enable_discount_combobox(self):
        if self.Dashboard_Table.rowCount() > 0:
            self.Set_Discount.setEnabled(True)
        else:
            self.Set_Discount.setEnabled(False)

    def void_selected_item(self):
        def generate_void_id():
            """Generate a unique 6-digit numeric ID."""
            return ''.join(random.choices(string.digits, k=6))

        selected_row = self.Dashboard_Table.currentRow()
        if selected_row >= 0:
            confirmation = QMessageBox.question(self, "Confirmation", "Are you sure you want to void this item?",
                                                QMessageBox.Yes | QMessageBox.No)
            if confirmation == QMessageBox.Yes:
                item = self.Dashboard_Table.item(selected_row, 0)
                if item is not None:
                    product_name = item.text()
                    try:
                        # Fetch the user_id of the currently logged-in user
                        self.mycursor.execute('SELECT user_id FROM accountmanagement WHERE activity = "ONLINE"')
                        user_id = self.mycursor.fetchone()[0]

                        # Fetch the item_list_id of the selected item
                        self.mycursor.execute(f"""
                            SELECT il.item_list_id FROM Item_List il
                            INNER JOIN masterlist m ON il.Barcode_Number = m.Barcode_Number
                            WHERE m.product_name = '{product_name}'
                        """)
                        item_list_id = self.mycursor.fetchone()[0]

                        # Generate a unique 6-digit Void_ID
                        void_id = generate_void_id()
                        while True:
                            self.mycursor.execute("SELECT COUNT(*) FROM void_list WHERE Void_ID = %s", (void_id,))
                            if self.mycursor.fetchone()[0] == 0:
                                break
                            void_id = generate_void_id()

                        # Get current date and time
                        date_voided = QDate.currentDate().toString("yyyy-MM-dd")
                        time_voided = QTime.currentTime().toString("hh:mm:ss")

                        # Log the voided item information in the void_list table
                        self.mycursor.execute("""
                            INSERT INTO void_list (Void_ID, user_id, item_list_id, date_voided, time_voided)
                            VALUES (%s, %s, %s, %s, %s)
                        """, (void_id, user_id, item_list_id, date_voided, time_voided))
                        self.mydb.commit()

                        # Delete the item from the Item_List table
                        query = f"""
                            DELETE i FROM Item_List i
                            INNER JOIN masterlist m ON i.Barcode_Number = m.Barcode_Number
                            WHERE m.product_name = '{product_name}'
                        """
                        self.mycursor.execute(query)
                        self.mydb.commit()
                        self.Dashboard_Table.removeRow(selected_row)
                        self.update_total_price()
                        self.calculate_total()
                    except mysql.connector.Error as err:
                        print("Error:", err)
        else:
            QMessageBox.warning(self, "No item selected", "Please select an item to void.")

    def update_total_price(self):
        total_price = 0.0
        for row in range(self.Dashboard_Table.rowCount()):
            quantity_item = self.Dashboard_Table.item(row, 1)
            price_item = self.Dashboard_Table.item(row, 2)
            if quantity_item and price_item:
                try:
                    quantity = float(quantity_item.text())
                    price_text = price_item.text().replace('₱', '')  # Remove currency symbol
                    price = float(price_text)
                    total_price += quantity * price
                except ValueError as e:
                    print(f"ValueError: {e}, skipping row {row}")

        self.Price_Label.setText(f"₱{total_price:.2f}")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
    dashboard_ui = Ui_dashboard()
    dashboard_ui.show()

    sys.exit(app.exec_())
