from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import bggg
UI = r"assets/ui/view_hop.ui"

class Ui_View_HOP(QtWidgets.QMainWindow):
    def __init__(self, transaction_id, *args, **kwargs):
        super(Ui_View_HOP, self).__init__(*args, **kwargs)
        uic.loadUi(UI, self)
        self.transaction_id = transaction_id
        self.setup_ui()

    def setup_ui(self):
        # Use self.transaction_id to fetch and display the relevant information
        self.setWindowTitle(f"Transaction Details - {self.transaction_id}")
        # Add code here to populate the UI with transaction details

# Set column count and headers
        self.ViewHOP_Table.setColumnCount(3)
        headers = ["Description", "Quantity", "Price"]
        self.ViewHOP_Table.setHorizontalHeaderLabels(headers)

        # Populate the table widget with data from bggg
        for row, item in enumerate(bggg):
            description = item["description"]
            quantity = item["quantity"]
            price = item["price"]

            # Insert data into table widget
            self.ViewHOP_Table.insertRow(row)
            self.ViewHOP_Table.setItem(row, 0, QTableWidgetItem(description))
            self.ViewHOP_Table.setItem(row, 1, QTableWidgetItem(str(quantity)))
            self.ViewHOP_Table.setItem(row, 2, QTableWidgetItem(str(price)))
        
        # Set window title
        self.setWindowTitle(f"Transaction Details - {self.transaction_id}")

if __name__ == "__main__":
    app = QApplication([])
    window1 = Ui_View_HOP("08293")  # Example transaction ID for testing
    window1.show()
    app.exec_()