from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import os

UI_DASHBOARD = r"assets\with_tab\tabwidget.ui"

class Ui_login(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_login, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)

        self.tabWidget.tabBar().hide()
        self.tabWidget.setStyleSheet("QTabWidget::pane { border: 0; margin: 0; padding: 0; }")



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_login()
    window1.show()
    sys.exit(app.exec_())