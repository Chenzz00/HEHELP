from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import database
import mysql.connector
import sys
import bggg
UI = r"assets\ui\Account_Management.ui"

#setup mysql database.
startup = database()
startup.create_table()#creating table with no arguement will select GENERALDATABASE as database
mydb = startup.mydb 

class Ui_accountManagement(QtWidgets.QWidget):
    userSelected = QtCore.pyqtSignal(str, str, str)

    def __init__(self):
        super(Ui_accountManagement, self).__init__()
        uic.loadUi(UI, self)
        
        self.connect_db()
        self.load_data()

        self.tableWidget.cellClicked.connect(self.handleCellClicked)
        self.pushButton_2.clicked.connect(self.openModifyAccount)
        self.setStyleSheet("QMainWindow { border-image: url(:/nice/bg.png);; }")

    def openModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        self.window.setup(1)  
        self.window.setWindowModality(Qt.ApplicationModal) 
        self.window.show()

    def handleCellClicked(self, row, column):
        username = self.tableWidget.item(row, 0).text()
        password = self.tableWidget.item(row, 1).text()
        status = self.tableWidget.item(row, 2).text()
        self.userSelected.emit(username, password, status)

    def connect_db(self):
        global mydb
        self.mycursor = mydb.cursor()

    def load_data(self):
        try:
            self.mycursor.execute("SELECT first_name, last_name, status  FROM accountmanagement")
            result = self.mycursor.fetchall()
            self.tableWidget.setRowCount(len(result))
            self.tableWidget.setColumnCount(3)
            self.tableWidget.setHorizontalHeaderLabels(['First Name','Last Name', 'Status'])
            for row_number, row_data in enumerate(result):
                for column_number, data in enumerate(row_data):
                    self.tableWidget.setItem(row_number, column_number, QTableWidgetItem(str(data)))
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + sqlstate
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)

        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window1 = Ui_accountManagement()
    window1.show()
    sys.exit(app.exec_())
