from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

# Import the generated resources module
import bggg

UI = r"assets/ui/Set_Discount.ui"

class Ui_SetDiscount(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_SetDiscount, self).__init__()
        uic.loadUi(UI, self)
        
        # Validator for the line edit
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        
        # Set a background image using the resource path
        self.setStyleSheet("QWidget { border-image: url(:/nice/bg.png); }")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_SetDiscount()
    window1.show()
    sys.exit(app.exec_())
