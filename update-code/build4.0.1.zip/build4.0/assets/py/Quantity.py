from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

UI = r"assets\ui\Quantity.ui"
import bggg

class Ui_Quantity(QtWidgets.QMainWindow):
    # Define quantityAdded as a class attribute
    quantityAdded = pyqtSignal(int)

    def __init__(self):
        super(Ui_Quantity, self).__init__()
        uic.loadUi(UI, self)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.Back_Button.clicked.connect(self.closeWindow)
        self.Add_Button.clicked.connect(self.emitQuantity)

    def emitQuantity(self):
        # Get the quantity input from the user
        quantity = int(self.Quantity_Number.value())
        # Emit the quantity
        self.quantityAdded.emit(quantity)
        # Close the Quantity UI
        self.close()
        
    def closeWindow(self):
        self.close()
    
    def displayUiQuantity(self):
        self.quantity_ui = Ui_Quantity()
        self.quantity_ui.quantityAdded.connect(self.handleQuantityAdded)
        self.quantity_ui.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    Quantity_Window = Ui_Quantity()
    Quantity_Window.show()
    sys.exit(app.exec_())
