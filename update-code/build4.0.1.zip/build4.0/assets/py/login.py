from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import database
import mysql.connector
import sys
import bggg

'''NOTE: THIS SCRIPT IS LIKE 95% COOL. JUST NEED TO FIND MORE BETTER WAYS TO RUN THE SCRIPT''' 

UI_LOGIN = r"assets\ui\LOGINUI.ui"

#creates database on startup. ignored if database exists.


class Ui_login(QtWidgets.QMainWindow):
    loginSuccessful = QtCore.pyqtSignal(str, str, str) 

    def __init__(self):
        super(Ui_login, self).__init__()
        uic.loadUi(UI_LOGIN, self)

        self.mydb = mysql.connector.connect(
            host = "localhost", 
            user = "root", 
            passwd = "CPET8L", 
            database = "generaldatabase", 
            port = 3306)
        self.mycursor = self.mydb.cursor()

        self.Username.setValidator(None)
        self.Password.setValidator(None)
        self.pushButton_2.clicked.connect(self.reset_owner)
        self.Login_Button.clicked.connect(self.validateLogin)
        self.Login_Button.setAutoDefault(True) 
        self.Login_Button.setDefault(True)  

        self.Login_Button.setShortcut(Qt.Key_Return)

        self.Username.setFocus()
        self.Username.setFocusPolicy(Qt.StrongFocus)
        self.Password.setFocusPolicy(Qt.StrongFocus)


    def validateLogin(self):
        username = self.Username.text()
        password = self.Password.text()
        selected_status = self.Role.currentText() 

        try:
            sql_query = "SELECT * FROM accountmanagement WHERE username = %s AND password = %s AND status = %s"
            self.mycursor.execute(sql_query, (username, password, selected_status))
            self.result = self.mycursor.fetchone()  

            if self.result:  
                db_status = self.result[2]
                if self.result[0] == "admin" and self.result[1] == "admin" and selected_status == "OWNER":
                    self.is_new_account = True
                    self.open_ModifyAccount()
                    self.showMessageBox("Please set up your owner account.", "Setup")
                    self.close()
                    
                elif db_status == selected_status:
                    self.loginSuccessful.emit(username, password, db_status)
                    self.openDashboard()
                    self.close()
                else:
                    self.showMessageBox("Invalid username, password, or user role.", "Login Failed")
            else:
                self.showMessageBox("Invalid username, password, or user role.", "Login Failed")

        except mysql.connector.Error as err:
            print("Error:", err)

    #TEST ONLY. DELETE WHEN SOFTWARE IS FINISHED
    def reset_owner(self):
        global mydb
        try:
            syntax = 'DELETE FROM accountmanagement WHERE status = "OWNER"'
            self.resetOwner = mydb.cursor()
            self.resetOwner.execute(syntax)
            self.mydb.commit()
            self.sql_query = "INSERT INTO accountmanagement (username, password, status) VALUES (%s, %s, %s)"
            self.value = ("admin", "admin", "OWNER")
            self.resetOwner.execute(self.sql_query, (self.value))
            self.mydb.commit()
            print("Successfully reset")


        except mysql.connector.Error as err:
            self.showMessageBox((err.errno, err.sqlstate, err.msg), "ERROR")


    def openDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.ui = Ui_dashboard()
        self.ui.setWindowModality(Qt.ApplicationModal)
        print(self.result)
        self.ui.fetch(self.result[4], self.result[2]) 
        self.ui.show()


    def openIntro(self):
        from intro import Ui_Intro
        self.intro = Ui_Intro()
        self.intro.show()


    def open_ModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        if self.is_new_account == True:
            self.window.setup(0)
            self.is_new_account = False  
        self.window.show()


    def showMessageBox(self, message, title):
        msg_box = QMessageBox()
        msg_box.setStyleSheet("background-color: white; color: rgba(0, 0, 0, 255);") 
        msg_box.setText(message)
        msg_box.setWindowTitle(title)
        msg_box.exec_()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_login()
    window1.show()
    sys.exit(app.exec_())
