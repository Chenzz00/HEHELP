from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import database
import mysql.connector
import sys
UI = r"assets\ui\Searching.ui"
import bggg
class Ui_searching(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_searching, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Barcode.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Search_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.mydb = mysql.connector.connect(
            host = "localhost", 
            user = "root", 
            passwd = "CPET8L", 
            database = "generaldatabase", 
            port = 3306)
        self.mycursor = self.mydb.cursor()

        self.load_data()

        
    def load_data(self):
        try:
            self.mycursor.execute("SELECT barcode_number, product_name, category, price  FROM masterlist")
            result = self.mycursor.fetchall()
            print(f"masterlist: {result}")
            self.Search_Table.setRowCount(len(result))
            for row_number, row_data in enumerate(result):
                for column_number, data in enumerate(row_data):
                    self.Search_Table.setItem(row_number, column_number, QTableWidgetItem(str(data)))
        except mysql.connector.Error as err:
            print(err)

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.fetch(self.name, self.stat)
        self.dashboard.show()
        self.close()

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()
    
    def fetch(self, slot1 = None, slot2 = None, slot3 = None, slot4 = None, slot5 = None):
        self.temp = []
        #checks if the slot is used to fetch (SLOT1 NAME, SLOT2 STATUS)
        if slot1 != None:
            self.temp.append(slot1)
        if slot2 != None:
            self.temp.append(slot2)
        if slot3 != None:
            self.temp.append(slot3)
        if slot4 != None:
            self.temp.append(slot4)
        if slot5 != None:
            self.temp.append(slot5)

        print(f"TEMP:{self.temp}")
        self.name = self.temp[0]
        self.stat = self.temp[1]

    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_searching()
    window1.show()
    sys.exit(app.exec_())
