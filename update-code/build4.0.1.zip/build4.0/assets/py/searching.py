from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from database_init import Database
from Quantity import Ui_Quantity
import mysql.connector
import sys
import bggg
UI = r"assets\ui\Searching.ui"

class Ui_searching(QtWidgets.QMainWindow):
    productSelected = pyqtSignal(str, float, int)
    def __init__(self):
        super(Ui_searching, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Barcode.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
       
        self.Search_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.Search_Barcode.textChanged.connect(self.searchBarcode)
        
        self.mydb = mysql.connector.connect(
            host = "localhost", 
            user = "root", 
            passwd = "CPET8L", 
            database = "generaldatabase", 
            port = 3306)
        self.mycursor = self.mydb.cursor()

        self.update_table()
        self.Search_Table.itemDoubleClicked.connect(self.clearSelection)  # Connect double-click event

    def update_table(self, data=None):
        try:
            if data is None:
                self.mycursor.execute("SELECT barcode_number, product_name, category, price  FROM masterlist")
                data = self.mycursor.fetchall()
            
            self.Search_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    self.Search_Table.setItem(row_number, column_number, QTableWidgetItem(str(value)))
        
        except mysql.connector.Error as err:
            print(err)
    
    


    
    

    


    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.fetch(self.name, self.stat)
        self.dashboard.show()
        self.close()

    def clearSelection(self):
        self.Search_Table.clearSelection()  # Clear table selection

    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()
    
    def fetch(self, slot1 = None, slot2 = None, slot3 = None, slot4 = None, slot5 = None):
        self.temp = []
        #checks if the slot is used to fetch (SLOT1 NAME, SLOT2 STATUS)
        if slot1 != None:
            self.temp.append(slot1)
        if slot2 != None:
            self.temp.append(slot2)
        if slot3 != None:
            self.temp.append(slot3)
        if slot4 != None:
            self.temp.append(slot4)
        if slot5 != None:
            self.temp.append(slot5)

        print(f"TEMP:{self.temp}")
        self.name = self.temp[0]
        self.stat = self.temp[1]

    def searchBarcode(self, barcode):
        try:
            query = "SELECT barcode_number, product_name, category, price FROM masterlist WHERE barcode_number LIKE %s"
            self.mycursor.execute(query, (f"{barcode}%",))  
            result = self.mycursor.fetchall()
            self.update_table(result)
        except mysql.connector.Error as err:
            print(err)

    

        

if __name__ == "__main__":
    app = QApplication(sys.argv)
    searching_window = Ui_searching()
    searching_window.show()
    sys.exit(app.exec_())