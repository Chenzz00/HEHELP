from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import bggg
UI = r"assets\ui\Manager_Tools.ui"

class Ui_manager_tools(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_manager_tools, self).__init__()
        uic.loadUi(UI, self)

        
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.HOP.clicked.connect(self.open_HistoryPurchase)
        self.Void_List.clicked.connect(self.open_Void)
        self.Masterlist.clicked.connect(self.open_Masterlist)
        self.Back_Button.setShortcut(Qt.Key_Escape)

  
        
    def open_Masterlist(self):
        from View_Masterlist import Ui_Masterlist
        self.masterlist = Ui_Masterlist()
        self.masterlist.setWindowModality(Qt.ApplicationModal)
        self.masterlist.show()
        self.close()
    
    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def open_Void(self):
        from Void import Ui_Void_List
        self.void = Ui_Void_List()
        self.void.setWindowModality(Qt.ApplicationModal)
        self.void.show()
        self.close()

    def open_HistoryPurchase(self):
        from History_Purchase import Ui_History_Purchase
        self.HOP = Ui_History_Purchase()
        self.HOP.setWindowModality(Qt.ApplicationModal)
        self.HOP.show()
        self.close()
        
    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                event.accept()
                self.backToDashboard()  
            else:
                event.ignore()
        else:
            event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_manager_tools()
    window1.show()
    sys.exit(app.exec_())