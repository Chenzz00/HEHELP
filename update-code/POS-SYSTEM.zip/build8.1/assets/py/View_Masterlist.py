from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import bggg

UI = r"assets\ui\View_Masterlist.ui"

class Ui_Masterlist(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Masterlist, self).__init__()
        uic.loadUi(UI, self)
        self.Masterlist_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        int_validator = QIntValidator(0, 2147483647)
        self.Search_Item.setValidator(int_validator)
        
        self.populate_table()

        self.search_timer = QTimer()
        self.search_timer.setInterval(500) 
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.searchBarcode)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Back_Button.setShortcut(Qt.Key_Escape)

        self.Search_Item.textChanged.connect(self.startSearchTimer)

        self.Filter_Category.setCurrentIndex(0)


        self.Filter_Category.currentIndexChanged.connect(self.filterCategory)

    def startSearchTimer(self):
 
        self.search_timer.start()

    def searchBarcode(self):
        barcode = self.Search_Item.text()
        self.search_timer.stop() 
        self.searchDatabase(barcode)

    def searchDatabase(self, barcode):
        try:
            query = "SELECT barcode_number, product_name, category, price FROM masterlist WHERE barcode_number LIKE %s"
            self.mycursor.execute(query, (f"{barcode}%",))  
            result = self.mycursor.fetchall()
            self.update_table(result)
        except mysql.connector.Error as err:
            print(err)

    def populate_table(self):
        try:
            
            self.mydb = mysql.connector.connect(
                host="localhost", 
                user="root", 
                passwd="CPET8L", 
                database="generaldatabase", 
                port=3306)
            self.mycursor = self.mydb.cursor()

            self.mycursor.execute("SELECT barcode_number, product_name, category, price, stock_left, stock FROM masterlist")
            data = self.mycursor.fetchall()

            self.Masterlist_Table.setRowCount(len(data))
            for row_num, row_data in enumerate(data):
                for col_num, col_data in enumerate(row_data):
                    col_data = col_data if col_data is not None else "N/A"
                    item = QTableWidgetItem(str(col_data))
                    self.Masterlist_Table.setItem(row_num, col_num, item)


            for row in range(self.Masterlist_Table.rowCount()):
                for column in range(self.Masterlist_Table.columnCount()):
                    item = self.Masterlist_Table.item(row, column)
                    if item:
                        item.setFlags(item.flags() & ~Qt.ItemIsSelectable)
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)  

        except mysql.connector.Error as err:
            print("Error:", err)

    def update_table(self, data=None):
        try:
            if data is None:
                self.mycursor.execute("SELECT barcode_number, product_name, category, price FROM masterlist")
                data = self.mycursor.fetchall()
            
            self.Masterlist_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    self.Masterlist_Table.setItem(row_number, column_number, QTableWidgetItem(str(value)))
        
        except mysql.connector.Error as err:
            print(err)

    def filterCategory(self):
        selected_index = self.Filter_Category.currentIndex()
        if selected_index == 0:  
            self.populate_table()
        else:
            try:
                selected_category = self.Filter_Category.currentText()
                if selected_category == "All" or selected_category == "":  
                    self.populate_table()
                else:
                   
                    query = "SELECT barcode_number, product_name, category, price FROM masterlist WHERE category = %s"
                    self.mycursor.execute(query, (selected_category,))
                    data = self.mycursor.fetchall()
                    
                  
                    self.update_table(data)
                    
            except mysql.connector.Error as err:
                print("Error:", err)
        
      
        self.Masterlist_Table.clearSelection()

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()




if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Masterlist()
    window1.show()
    sys.exit(app.exec_())
