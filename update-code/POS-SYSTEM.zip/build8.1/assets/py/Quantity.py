from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import bggg

UI = r"assets\ui\Quantity.ui"

class Ui_Quantity(QtWidgets.QMainWindow):
    # Define quantityAdded as a class attribute
    quantityAdded = pyqtSignal(int)

    def __init__(self):
        super(Ui_Quantity, self).__init__()
        uic.loadUi(UI, self)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.Back_Button.clicked.connect(self.closeWindow)
        self.Add_Button.clicked.connect(self.emitQuantity)
        self.Add_Button.setShortcut(Qt.Key_Return)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        # Set minimum value of Quantity_Number to 1
        self.Quantity_Number.setMinimum(1)

    def emitQuantity(self):
        quantity = int(self.Quantity_Number.value())
        self.quantityAdded.emit(quantity)
        self.close()
        
    def closeWindow(self):
        self.close()
    
    def displayUiQuantity(self):
        self.show()  # Show the window
        self.Quantity_Number.setFocus()  # Set focus to the input field


if __name__ == "__main__":
    app = QApplication(sys.argv)
    Quantity_Window = Ui_Quantity()
    Quantity_Window.displayUiQuantity()  # Call displayUiQuantity instead of show directly
    sys.exit(app.exec_())
