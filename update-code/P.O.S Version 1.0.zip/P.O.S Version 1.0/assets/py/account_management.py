from PyQt5 import QtWidgets, uic, QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

import mysql.connector
import sys
import bggg
UI = r"assets\ui\Account_Management.ui"


class Ui_accountManagement(QtWidgets.QMainWindow):
    userSelected = QtCore.pyqtSignal(str, str, str)

    def __init__(self):
        super(Ui_accountManagement, self).__init__()
        uic.loadUi(UI, self)

        self.load_data()

        self.Account_Table.cellClicked.connect(self.handleCellClicked)
        self.Create_Button.clicked.connect(self.openModifyAccount)
        self.Refresh_Button.clicked.connect(self.load_data)
        self.Delete_Button.clicked.connect(self.delete_account)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.Back_Button.setShortcut(Qt.Key_Escape)
        self.Change_Button.clicked.connect(self.openPermission)

        self.setStyleSheet("QMainWindow { border-image: url(:/nice/bg.png);; }")
        self.check_permissions()

    def check_permissions(self):
        #TODO fetch the current user's uid then use that to fetch their permissions.
        self.mycursor.execute("SELECT user_id FROM accountmanagement WHERE activity = 'ONLINE'")
        result = self.mycursor.fetchone()
        self.mycursor.execute("SELECT * FROM permissions WHERE user_id = %s", result)
        result_permission = self.mycursor.fetchone()
        self.Create_Button.setEnabled(True)
        self.Delete_Button.setEnabled(True)
        self.Change_Button.setEnabled(True)
        if result_permission[8] == 0:
            self.Create_Button.setEnabled(False)
        if result_permission[9] == 0:
            self.Delete_Button.setEnabled(False)
        if result_permission[0] == 0:
            self.Change_Button.setEnabled(False)

    def openPermission(self):
        selected_row = self.Account_Table.currentRow()
        
        if selected_row >= 0:
            from Permissions import Ui_Permissions
            self.window = Ui_Permissions()
            self.window.setWindowModality(Qt.ApplicationModal)  
            fname = self.Account_Table.item(selected_row, 0).text()
            lname = self.Account_Table.item(selected_row, 1).text()
            status = self.Account_Table.item(selected_row, 2).text()
            self.window.get_user_details(fname, lname, status)
            self.window.show()
        else:
            QtWidgets.QMessageBox.information(self, 'Change Permission', 'Please select a row first.')


    def openModifyAccount(self):
        from modify_account import Ui_Register
        self.window = Ui_Register()
        self.window.setup(1)  
        self.window.setWindowModality(Qt.ApplicationModal) 
        self.window.show()

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.window = Ui_dashboard()
        self.window.show()
        self.hide()


    def handleCellClicked(self, row, column):
        username = self.Account_Table.item(row, 0).text()
        password = self.Account_Table.item(row, 1).text()
        status = self.Account_Table.item(row, 2).text()
        self.userSelected.emit(username, password, status)

    def load_data(self):
        self.Account_Table.setRowCount(0)
        try:
            #connect to mysql database
            self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "CPET8L",
            port = 3306,
            database = "generaldatabase"
        )
            self.mycursor = self.mydb.cursor()

            self.mycursor.execute("SELECT first_name, last_name, status  FROM accountmanagement")
            result = self.mycursor.fetchall()
            self.Account_Table.setRowCount(len(result))
            self.Account_Table.setColumnCount(3)
            self.Account_Table.setHorizontalHeaderLabels(['First Name','Last Name', 'Status'])
            print(result)
            for row_number, row_data in enumerate(result):
                for column_number, data in enumerate(row_data):
                    item = QTableWidgetItem(str(data))
                    self.Account_Table.setItem(row_number, column_number, item)
            self.update()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    def delete_account(self):
        selected_row = self.Account_Table.currentRow()
        if selected_row >= 0:
            confirm_dialog = QtWidgets.QMessageBox.question(self, 'Delete Account', 
                                                            'Are you sure you want to delete this account?', 
                                                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
            if confirm_dialog == QtWidgets.QMessageBox.Yes:
                # Get the username from the selected row
                username = self.Account_Table.item(selected_row, 0).text()
                try:
                    # Connect to the MySQL database
                    self.mydb = mysql.connector.connect(
                        host="localhost",
                        user="root",
                        passwd="CPET8L",
                        port=3306,
                        database="generaldatabase"
                    )
                    self.mycursor = self.mydb.cursor()

                    # Delete the row from the database
                    sql = "DELETE FROM accountmanagement WHERE first_name = %s"
                    val = (username,)
                    self.mycursor.execute(sql, val)
                    self.mydb.commit()

                    # Remove the row from the table widget
                    self.Account_Table.removeRow(selected_row)
                    
                    # Clear the selection
                    self.Account_Table.clearSelection()

                    QtWidgets.QMessageBox.information(self, 'Delete Account', 'Account deleted successfully.')

                except mysql.connector.Error as err:
                    self.errorDisplay(err.errno, err.sqlstate, err.msg)
        else:
            QtWidgets.QMessageBox.information(self, 'Delete Account', 'Please select a row to delete.')


    def errorDisplay(self, errorCode, sqlstate, text):
        error1 = "Error Code: " + str(errorCode)
        error2 = "SQL State: " + sqlstate
        error3 = "Description: " + text
        QtWidgets.QMessageBox.critical(None, "Error", error1 + "\n" + error2 + "\n" + error3)

    def closeEvent(self, event):
        from close import Ui_close
        self.close_dialog = Ui_close()
        self.close_dialog.setWindowModality(Qt.ApplicationModal)

        result = self.close_dialog.exec_()

        if result == QDialog.Accepted:
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window1 = Ui_accountManagement()
    window1.show()
    sys.exit(app.exec_())
