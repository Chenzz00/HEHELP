-- SET SQL_SAFE_UPDATES = 0;
UPDATE users
SET username = "admin", password = "admin"
WHERE status = "OWNER";
SELECT * FROM generaldatabase;