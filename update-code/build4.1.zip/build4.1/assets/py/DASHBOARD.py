from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import os
import bggg


# Import UI files
UI_DASHBOARD = r"assets\ui\Dashboard.ui"



class Ui_dashboard(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_dashboard, self).__init__()
        uic.loadUi(UI_DASHBOARD, self)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  
        self.Search_Button.clicked.connect(self.openSearch)
        self.CheckOut.clicked.connect(self.openCheckOut)
        self.Manager_Tools.clicked.connect(self.openManagerTools)
        self.Dashboard_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.pushButton_7.clicked.connect(self.openAccountManagement)
        self.update_time()

        
    def openSearch(self):
        from searching import Ui_searching
        self.window = Ui_searching()  
        self.window.setWindowModality(Qt.ApplicationModal) 
        self.window.fetch(self.temp[0], self.temp[1])
        self.window.show()
        self.hide()
        
    def openCheckOut(self):
        from Checkout import Ui_checkout
        self.checkout = Ui_checkout()
        self.checkout.setWindowModality(Qt.ApplicationModal)
        self.checkout.show()
        self.hide()
    
    def openAccountManagement(self):
        from account_management import Ui_accountManagement
        self.managertools = Ui_accountManagement()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.hide()
        pass

    def openManagerTools(self):
        from Manager_tools import Ui_manager_tools
        self.managertools = Ui_manager_tools()
        self.managertools.setWindowModality(Qt.ApplicationModal)
        self.managertools.show()
        self.hide()

    def update_time(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        time_text = current_time.toString("hh:mm:ss AP")
        date_text = current_date.toString("MM/dd/yy")
        self.DateTime_Label.setText(f"{time_text}  {date_text}")
        font = self.DateTime_Label.font()
        font.setPointSize(19)  
        self.DateTime_Label.setFont(font)

    def backToLogin(self):
        from login import Ui_login
        self.login = Ui_login()
        self.login.show()
        self.close()

    def unhide(self):
        self.show()
    

    def closeEvent(self, event):
        if event.spontaneous():
            from logout import Ui_logout
            self.close_dialog = Ui_logout()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                self.backToLogin()
                event.accept()
                
            else:
                event.ignore()
        else:
            event.accept()

    def fetch(self, slot1 = None, slot2 = None, slot3 = None, slot4 = None, slot5 = None):
        self.temp = []
        #checks if the slot is used to fetch (SLOT1 NAME, SLOT2 STATUS)
        if slot1 != None:
            self.temp.append(slot1)
        if slot2 != None:
            self.temp.append(slot2)
        if slot3 != None:
            self.temp.append(slot3)
        if slot4 != None:
            self.temp.append(slot4)
        if slot5 != None:
            self.temp.append(slot5)

        print(f"TEMP:{self.temp}")
        #use fetched data to set this widget
        self.User_Label.setText(f"WELCOME {self.temp[0].upper()}! USER ROLE: {self.temp[1]}")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_dashboard()
    window.fetch("DEBUG USER", "OWNER")
    window.show()

    sys.exit(app.exec_())
