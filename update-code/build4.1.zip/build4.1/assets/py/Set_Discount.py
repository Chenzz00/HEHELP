from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import bggg

UI = r"assets/ui/Set_Discount.ui"

class Ui_SetDiscount(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_SetDiscount, self).__init__()
        uic.loadUi(UI, self)
        
        # Validator for the line edit
        int_validator = QIntValidator(0, 2147483647)
        self.Amount.setValidator(int_validator)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_SetDiscount()
    window1.show()
    sys.exit(app.exec_())
