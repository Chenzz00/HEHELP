import mysql.connector
from mysql.connector import errorcode

#pls put the items here :)
items = [(1906949,"Emperador Gold | Philippines Fruit Brandy 750ml",189,"ALCOHOL"),
(1131822,"Alfonso I Platinum - Spanish Brandy de Jerez 700ml", 399, "ALCOHOL"
)]

    
#GENERAL DATABASE CREATOR
class database:

    def __init__(self):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "CPET8L",
            port = 3306
        )
        self.mycursor = self.mydb.cursor()

    def create_db(self):
        try:
            self.mycursor.execute("CREATE DATABASE GeneralDatabase")
            self.mydb = mysql.connector.connect(database = "generaldatabase")
            return "Database is succesfully created"

        except mysql.connector.Error as err:
            return err

    def create_table(self, id = None):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "CPET8L",
            port = 3306,
            database = "generaldatabase"
        )
        self.mycursor = self.mydb.cursor()
        #accounts
        if id == 0:
            try:
                self.mycursor.execute("CREATE TABLE accountmanagement(username VARCHAR(255), password VARCHAR(255), status VARCHAR(255), last_updated TIMESTAMP, first_name VARCHAR(255), last_name VARCHAR(255))")
                self.sql_query = "INSERT INTO accountmanagement (username, password, status) VALUES (%s, %s, %s)"
                self.value = ("admin", "admin", "OWNER")
                self.mycursor.execute(self.sql_query, (self.value))
                self.mydb.commit()
                return "Table successfully created"
            except mysql.connector.Error as err:
                print(err)
        
        #masterlist
        elif id == 1:
            global items
            try:
                #table creation
                self.mycursor.execute("CREATE TABLE masterlist(barcode_number INT, product_name VARCHAR(255), price FLOAT, stock_left INT, stock INT, category VARCHAR(255), lastUpdated TIMESTAMP)")
                #data insert
                for i in items:
                    barcode = i[0]
                    name = i[1]
                    price = i[2]
                    category = i[3]
                    stock = 100

                    self.sql_query = "INSERT INTO masterlist (barcode_number, product_name, price, stock_left, stock, category) VALUES (%s, %s, %s, %s, %s, %s)"
                    self.value = (barcode, name, price, stock, stock, category)
                    self.mycursor.execute(self.sql_query, (self.value))
                    self.mydb.commit()
                return "Table successfully created"
            except mysql.connector.Error as err:
                print(err)

        else:
            return "TABLE ALREADY CREATED"

    def reset_db(self):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "CPET8L",
            port = 3306,
            database = "generaldatabase"
        )
        self.mycursor = self.mydb.cursor()
        try:
            self.mycursor.execute("DROP DATABASE generaldatabase")
            return "DATABASE SUCCESSFULLY DROPPED"
        
        except mysql.connector.Error as err:
            print(err)

    def reset_table(self, id):
        self.mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            passwd = "CPET8L",
            port = 3306,
            database = "generaldatabase"
        )
        self.mycursor = self.mydb.cursor()
        if id == 0:
            try:
                self.mycursor.execute("DROP TABLE accountmanagement")
                return "Table Successfully Dropped"

            except mysql.connector.Error as err:
                print(err)
            
        elif id == 1:
            try:
                self.mycursor.execute("DROP TABLE masterlist")
                return "Table Successfully Dropped"

            except mysql.connector.Error as err:
                print(err)

    def setup_items(self):
        pass


'''WARNING: 
RUNNING THIS SCRIPT WILL DEFINITELY OBLITERATE YOUR SAVE IN DATABASE. 
DO NOT RUN THIS SCRIPT AS MAIN IF YOU DONT WANT THAT'''
if __name__ == "__main__":
    DB = database()
    DB.reset_table(1)
    DB.create_table(1)
