from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import bggg

UI = r"assets\ui\View_Masterlist.ui"

class Ui_Masterlist(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_Masterlist, self).__init__()
        uic.loadUi(UI, self)
        #int_validator = QIntValidator(0, 2147483647)
        #self.Search_Item.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToMTools)
        
        self.Masterlist_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)    
    

    def backToMTools(self):
        from Manager_tools import Ui_manager_tools
        self.mTools = Ui_manager_tools()
        self.mTools.show()
        self.close()
    
    def closeEvent(self, event):
        if event.spontaneous():
            from close import Ui_close
            self.close_dialog = Ui_close()
            self.close_dialog.setWindowModality(Qt.ApplicationModal)
            
            result = self.close_dialog.exec_()

            if result == QDialog.Accepted:
                self.backToMTools()
                event.accept()
                
            else:
                event.ignore()
        else:
            event.accept()
  


    #def populate_table(self):
        # Disable sorting temporarily
            #self.tableWidget.setSortingEnabled(False)

            #SAMPLE DATA    
            #self.tableWidget.setRowCount(1)  
            #self.tableWidget.setItem(0, 0, QTableWidgetItem("12321312"))
            #self.tableWidget.setItem(0, 1, QTableWidgetItem("Fudgebar"))
            #self.tableWidget.setItem(0, 2, QTableWidgetItem("Rebisco"))
            #self.tableWidget.setItem(0, 3, QTableWidgetItem("Cake"))
            #self.tableWidget.setItem(0, 4, QTableWidgetItem("10"))
            #self.tableWidget.setItem(0, 5, QTableWidgetItem("Available"))
            #self.tableWidget.setItem(0, 6, QTableWidgetItem("20"))

            #self.tableWidget.setRowCount(2)  
            #self.tableWidget.setItem(1, 0, QTableWidgetItem("54354334"))
            #self.tableWidget.setItem(1, 1, QTableWidgetItem("Skyflakes"))
            #self.tableWidget.setItem(1, 2, QTableWidgetItem("Monde Nissin Corp."))
            #self.tableWidget.setItem(1, 3, QTableWidgetItem("Biscuit"))
            #self.tableWidget.setItem(1, 4, QTableWidgetItem("9"))
            #self.tableWidget.setItem(1, 5, QTableWidgetItem("Available"))
            #self.tableWidget.setItem(1, 6, QTableWidgetItem("20"))

            #self.tableWidget.setRowCount(3)  
            #self.tableWidget.setItem(2, 0, QTableWidgetItem("32432432"))
            #self.tableWidget.setItem(2, 1, QTableWidgetItem("Sting"))
            #self.tableWidget.setItem(2, 2, QTableWidgetItem("Sting Energy"))
            #self.tableWidget.setItem(2, 3, QTableWidgetItem("Drinks"))
            #self.tableWidget.setItem(2, 4, QTableWidgetItem("26"))
            #self.tableWidget.setItem(2, 5, QTableWidgetItem("Available"))
            #self.tableWidget.setItem(2, 6, QTableWidgetItem("20"))

            '''self.tableWidget.setRowCount(4)  
            self.tableWidget.setItem(3, 0, QTableWidgetItem(""))
            self.tableWidget.setItem(3, 1, QTableWidgetItem(""))
            self.tableWidget.setItem(3, 2, QTableWidgetItem(""))
            self.tableWidget.setItem(3, 3, QTableWidgetItem(""))
            self.tableWidget.setItem(3, 4, QTableWidgetItem(""))'''#template

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Masterlist()
    
    window1.show()
    sys.exit(app.exec_())        