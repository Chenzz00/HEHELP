from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import mysql.connector
import sys
import bggg
UI = r"assets\ui\History_Of_Purchase.ui"

class Ui_History_Purchase(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_History_Purchase, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)
        self.Back_Button.clicked.connect(self.backToDashboard)
        self.HOP_Table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Establish a database connection
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="CPET8L",
            database="generaldatabase",
            port=3306)
        self.mycursor = self.mydb.cursor()

       
        self.populate_dashboard_table()

        # Connect double-click event to deselect the row
        self.HOP_Table.itemDoubleClicked.connect(self.deselectRow)

    def populate_dashboard_table(self):
        try:
            # Fetch transaction ID, cashier's name, transaction date, and transaction time
            query = """
                SELECT hp.Transaction_ID, am.first_name, hp.Transaction_Date, hp.Transaction_Time
                FROM HistoryOfPurchase hp
                INNER JOIN accountmanagement am ON hp.user_id = am.user_id
            """
            self.mycursor.execute(query)
            data = self.mycursor.fetchall()

            self.HOP_Table.setRowCount(len(data))
            for row_number, row_data in enumerate(data):
                for column_number, value in enumerate(row_data):
                    item = QTableWidgetItem(str(value))
                    item.setTextAlignment(Qt.AlignCenter)  # Center-align the text
                    self.HOP_Table.setItem(row_number, column_number, item)
                    item.setBackground(QColor(38, 47, 52, 100))
                    item.setForeground(QColor(255, 255, 255))

        except mysql.connector.Error as err:
            print(err)


    def deselectRow(self, item):
        self.HOP_Table.clearSelection()

    def backToDashboard(self):
        from DASHBOARD import Ui_dashboard
        self.dashboard = Ui_dashboard()
        self.dashboard.show()
        self.close()

    def closeEvent(self, event):
        # Code to handle window close event
        pass

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_History_Purchase()
    window1.show()
    sys.exit(app.exec_())
