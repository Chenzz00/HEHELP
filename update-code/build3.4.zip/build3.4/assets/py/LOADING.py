from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
UI = r"assets\ui\LOADING.ui"

class Ui_Loading(QtWidgets.QWidget):
    def __init__(self):
        super(Ui_Loading, self).__init__()
        uic.loadUi(UI, self)
        int_validator = QIntValidator(0, 2147483647)
        self.lineEdit.setValidator(int_validator)

        self.setWindowFlags(QtCore.Qt.CustomizeWindowHint | QtCore.Qt.FramelessWindowHint)


        # Set up timer for updating progress
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_progress)
        self.progress = 0
        self.timer.start(100)  # Update every 100 milliseconds

    def update_progress(self):
        self.progress += 5
        self.ui.progressBar.setValue(self.progress)
        if self.progress >= 100:
            self.timer.stop()
            self.close()
    
            

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Ui_Loading()
    window1.show()
    sys.exit(app.exec_())  
